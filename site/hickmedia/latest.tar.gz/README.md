# Sovereign Media Hub (installer payload)

```bash
sudo bash installer/install.sh --profile full-hub --yes
# curl -fsSL https://www.destroythekraken.com/hickmedia.sh | sudo sh
```

Profiles: full-hub | media-client | media-server

This package contains no personal phone numbers or emails.
Support: your deploying technician or the contact form on destroythekraken.com.
