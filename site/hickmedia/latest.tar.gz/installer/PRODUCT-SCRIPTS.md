# Product vs legacy scripts

## Product (installer may call these)

| Script | Role |
|--------|------|
| `installer/install.sh` | **Entry point** for customers / VTS |
| `scripts/build-retroarch-playlists.sh` | Playlist build after ROMs present |
| `scripts/configure-8bitdo-dual.sh` | Dual pad defaults |
| `scripts/configure-retroarch-frontend.sh` | Deep RA frontend (lab; optional) |
| `scripts/configure-retro-tv-bezels.sh` | CRT bezels (optional polish) |
| `scripts/scrape-libretro-media.py` | Box art / metadata scrape |
| `scripts/scrape-and-decorate.sh` | Art + bezel one-shot |
| `scripts/verify-controllers.sh` | Pad health check |
| `scripts/health-check.sh` | Host health |
| `scripts/disable-sleep.sh` | Appliance (also in installer/lib) |
| `scripts/apply-user-audio.sh` | PipeWire user audio (pro/family) |
| `scripts/ht-audio-route.sh` + units | 1810c routing (pro audio only) |

## Legacy / family-only (`scripts/legacy/`)

Not for customer installs. Kept for lab history.

| Script | Why legacy |
|--------|------------|
| `download-mlp-archive.sh` | Family MLP archive.org pull |
| `download-mlp-to-nas.sh` | Family NAS copy |
| `transfer-status.sh` | One-off transfer monitoring |
| `setup-mov-serve.sh` | Hickmedia Tailscale `/mov` lab path |
| `rsync-roms-to-hub.sh` | Family NAS ROM sync |
| `post-studio-bootstrap.sh` | Superseded by installer |
| `sudo-setup.sh` | Superseded by installer |
| `hickmedia-sudo-once.sh` | Superseded by installer |
| `bootstrap-privileged.sh` | Stub / superseded |
| `inventory-remote.sh` | Lab inventory |

## Do not commit

- Jellyfin live `config/` / `cache/`  
- Logs, ROM files, credentials  
