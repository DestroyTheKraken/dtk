# Sovereign Media Hub — Installer

Customer package from **HickMedia**. Private on-prem media + entertainment desktop with **pro audio essential** (interface → speakers for Movies / Music / Gaming).

## Easiest: one-liner (online)

```bash
curl -fsSL https://www.destroythekraken.com/hickmedia.sh | sudo sh
curl -fsSL https://www.destroythekraken.com/hickmedia.sh | sudo sh -s -- --profile full-hub
```

Same pattern as Grok Build: small bootstrap downloads the full release, then runs this installer.  
Details: [`docs/CURL-INSTALL.md`](../docs/CURL-INSTALL.md).

**Update:** re-run the same curl line, or `sudo mediahub-update`.

## USB / offline

```bash
# Build onto a stick
bash installer/pack-release.sh --out /run/media/$USER/VENTOY/hickmedia

# Customer PC
sudo sh /media/$USER/VENTOY/hickmedia/hickmedia.sh --profile full-hub --yes
```

## Direct (tree already on disk)

```bash
sudo bash installer/install.sh --profile full-hub --yes
sudo bash installer/install.sh --os-help
```

## Profiles

| Profile | Delivers |
|---------|----------|
| `full-hub` | Client + Jellyfin server + appliance + RetroArch + **pro audio** |
| `media-client` | Desktop hub + **pro audio** + RetroArch |
| `media-server` | On-prem Jellyfin + **pro audio** + media dirs |

## Always installed (every profile)

- **Pro audio:** PipeWire @ 48 kHz → USB interface → external speakers  
- Profiles: `ht-audio-profile.sh movies|music|gaming`  
- Firefox default browser · Brave Search  
- Linger + optional no-sleep (appliance profiles)

See [`docs/AUDIO-PRODUCT.md`](../docs/AUDIO-PRODUCT.md).

## Base OS

| Choice | Notes |
|--------|--------|
| Ubuntu Desktop / Kubuntu 26.04 LTS | Default |
| Ubuntu Studio 26.04 | Excellent with audio interfaces |
| 24.04 LTS | OK if standardized |

## Publish website bits

```bash
bash installer/pack-release.sh --out ~/dist/hickmedia
# Upload:
#   hickmedia.sh              → https://www.destroythekraken.com/hickmedia.sh
#   hickmedia-latest.tar.gz   → https://www.destroythekraken.com/hickmedia/latest.tar.gz
```

## Env overrides

`HM_MEDIA_ROOT` `HM_JELLYFIN_PORT` `HM_JELLYFIN_PUBLISHED_URL` `HM_RELEASE_URL` `HM_YES=1` `HM_SKIP_RETRO=1` `HM_SKIP_DOCKER=1`
