#!/usr/bin/env bash
# =============================================================================
# Sovereign Media Hub installer (HickMedia product defaults)
# =============================================================================
# Prefer one-liner bootstrap (downloads this tree or runs from USB):
#   curl -fsSL https://destroythekraken.com/hickmedia.sh | sudo sh
#   curl -fsSL https://destroythekraken.com/hickmedia.sh | sudo sh -s -- --profile full-hub
#
# Direct (already have the tree on disk / USB):
#   sudo bash installer/install.sh --profile full-hub --yes
#
# Pro audio is ESSENTIAL: PipeWire @ 48 kHz → USB audio interface → speakers
# (Movies / Music / Gaming profiles). Not optional.
#
# Environment overrides:
#   HM_USER  HM_MEDIA_ROOT  HM_JELLYFIN_ROOT  HM_JELLYFIN_PORT
#   HM_JELLYFIN_URL  HM_JELLYFIN_PUBLISHED_URL
#   HM_SKIP_RETRO=1  HM_SKIP_DOCKER=1  HM_YES=1
# =============================================================================
set -euo pipefail

INSTALLER_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/common.sh
source "${INSTALLER_DIR}/lib/common.sh"
# shellcheck source=lib/os-check.sh
source "${INSTALLER_DIR}/lib/os-check.sh"
# shellcheck source=lib/packages.sh
source "${INSTALLER_DIR}/lib/packages.sh"
# shellcheck source=lib/appliance.sh
source "${INSTALLER_DIR}/lib/appliance.sh"
# shellcheck source=lib/desktop-defaults.sh
source "${INSTALLER_DIR}/lib/desktop-defaults.sh"
# shellcheck source=lib/jellyfin-server.sh
source "${INSTALLER_DIR}/lib/jellyfin-server.sh"
# shellcheck source=lib/retroarch.sh
source "${INSTALLER_DIR}/lib/retroarch.sh"
# shellcheck source=lib/audio-pro.sh
source "${INSTALLER_DIR}/lib/audio-pro.sh"

PROFILE="media-client"
YES=0

usage() {
  cat <<EOF
Sovereign Media Hub installer

Profiles:
  media-client   Desktop entertainment hub (Firefox, Jellyfin client, optional RetroArch)
  media-server   On-prem Jellyfin Docker server + media directories
  full-hub       Client + server + always-on appliance defaults

Options:
  --profile NAME   One of: media-client | media-server | full-hub
  --yes            Non-interactive (HM_YES=1)
  --os-help        Print OS recommendation and exit
  -h, --help       This help

Examples:
  sudo bash installer/install.sh --profile full-hub
  sudo HM_MEDIA_ROOT=/data/media bash installer/install.sh --profile media-server --yes
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile) PROFILE="${2:-}"; shift 2 ;;
    --yes|-y) YES=1; export HM_YES=1; shift ;;
    --os-help) hm_os_recommend; exit 0 ;;
    -h|--help) usage; exit 0 ;;
    *) die "unknown arg: $1" ;;
  esac
done

export HM_YES="${HM_YES:-$YES}"

case "$PROFILE" in
  media-client|media-server|full-hub) ;;
  *) die "invalid profile: $PROFILE" ;;
esac

log "=== Sovereign Media Hub install ==="
log "profile=${PROFILE} user=$(target_user) home=$(target_home)"
log "repo=${HM_REPO_ROOT}"
hm_os_report
hm_os_recommend

if ! hm_os_is_ubuntu_family; then
  warn "Non-Ubuntu/Debian family OS — continuing best-effort"
fi

if [[ "${HM_YES}" != "1" ]]; then
  confirm "Install profile '${PROFILE}' on this machine?" || die "aborted"
fi

# Root required for packages / appliance / docker
NEED_ROOT=1
if [[ "$NEED_ROOT" -eq 1 ]] && ! is_root; then
  die "re-run with sudo: sudo bash installer/install.sh --profile ${PROFILE}"
fi

hm_suggest_studio_trim

# --- always: base packages + desktop browser defaults ---
hm_apt_base
hm_desktop_firefox_default_browser
hm_desktop_brave_search

# --- always: pro audio (Movies / Music / Gaming via interface → speakers) ---
hm_audio_pro_essential
hm_appliance_linger

DO_CLIENT=0
DO_SERVER=0
DO_APPLIANCE=0
DO_RETRO=0

case "$PROFILE" in
  media-client)
    DO_CLIENT=1
    DO_RETRO=1
    DO_APPLIANCE=1
    ;;
  media-server)
    DO_SERVER=1
    DO_APPLIANCE=1
    ;;
  full-hub)
    DO_CLIENT=1
    DO_SERVER=1
    DO_APPLIANCE=1
    DO_RETRO=1
    ;;
esac

[[ "${HM_SKIP_RETRO:-0}" == "1" ]] && DO_RETRO=0
[[ "${HM_SKIP_DOCKER:-0}" == "1" ]] && DO_SERVER=0

if [[ "$DO_APPLIANCE" -eq 1 ]]; then
  hm_appliance_no_sleep
  hm_appliance_wifi_powersave_off
fi

if [[ "$DO_CLIENT" -eq 1 ]]; then
  hm_flatpak_user
  # default jellyfin URL for client bookmarks
  if [[ "$DO_SERVER" -eq 1 ]]; then
    export HM_JELLYFIN_URL="${HM_JELLYFIN_URL:-http://127.0.0.1:${HM_JELLYFIN_PORT:-8096}}"
  fi
fi

if [[ "$DO_RETRO" -eq 1 ]]; then
  hm_apt_retro
  hm_retroarch_defaults
fi

if [[ "$DO_SERVER" -eq 1 ]]; then
  hm_apt_docker
  hm_jellyfin_prepare_dirs
  hm_jellyfin_write_compose
  # docker group may not apply in this shell — start as root
  (cd "${HM_JELLYFIN_ROOT:-/srv/mediahub/jellyfin}" && docker compose up -d) || \
    warn "docker compose up failed — run after re-login: cd ${HM_JELLYFIN_ROOT:-/srv/mediahub/jellyfin} && docker compose up -d"
fi

if [[ "$DO_CLIENT" -eq 1 || "$DO_SERVER" -eq 1 ]]; then
  hm_desktop_launchers
fi

# Install product tree pointer for techs
if is_root; then
  mkdir -p /opt/mediahub
  # Symlink scripts if installing from a full clone
  if [[ -d "${HM_REPO_ROOT}/scripts" ]]; then
    ln -sfn "${HM_REPO_ROOT}" /opt/mediahub/HickMedia
    ln -sfn "${HM_REPO_ROOT}/scripts" /opt/mediahub/scripts
  fi
  cat >/opt/mediahub/VERSION <<EOF
product=Sovereign Media Hub
source=HickMedia
profile=${PROFILE}
installed=$(date -Is)
user=$(target_user)
EOF
fi

log ""
log "=== Install complete (${PROFILE}) ==="
log "Log: ${HM_LOG}"
log ""
log "Next steps:"
if [[ "$DO_SERVER" -eq 1 ]]; then
  log "  1. Open http://HOST_IP:${HM_JELLYFIN_PORT:-8096}/  → create Jellyfin admin"
  log "  2. Copy media into ${HM_MEDIA_ROOT:-/srv/mediahub/media}/{movies,tv,music}"
  log "  3. Add libraries at container paths /media/movies etc."
fi
if [[ "$DO_CLIENT" -eq 1 ]]; then
  log "  • Desktop: Watch (Jellyfin) · Web (Firefox) · Play (RetroArch if installed)"
  log "  • Default browser: Firefox · Default search: Brave Search"
fi
log "  • Pro audio: Apps → PipeWire@48k → USB interface → speakers"
log "  • Profiles: ht-audio-profile.sh movies|music|gaming"
if [[ "$DO_APPLIANCE" -eq 1 ]]; then
  log "  • Sleep/suspend masked; user linger enabled"
fi
log "  • Re-login once so docker group / audio group / desktop session apply"
log "  • Update: curl -fsSL https://destroythekraken.com/hickmedia.sh | sudo sh"
log "            or: mediahub-update"
log ""
log "VTS handoff: installer/README.md · docs/PRODUCT-MEDIA-HUB.md · docs/CURL-INSTALL.md"
