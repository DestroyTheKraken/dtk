#!/usr/bin/env bash
# Always-on appliance: no sleep, linger, optional Wi-Fi powersave off.
# shellcheck source=common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

hm_appliance_no_sleep() {
  is_root || die "hm_appliance_no_sleep needs root"
  log "Mask sleep targets + logind ignore"
  for t in sleep.target suspend.target hibernate.target hybrid-sleep.target; do
    systemctl mask "$t" 2>/dev/null || true
  done
  mkdir -p /etc/systemd/logind.conf.d
  cat >/etc/systemd/logind.conf.d/00-mediahub-no-sleep.conf <<'EOF'
[Login]
HandleSuspendKey=ignore
HandleHibernateKey=ignore
HandleLidSwitch=ignore
HandleLidSwitchExternalPower=ignore
HandleLidSwitchDocked=ignore
IdleAction=ignore
IdleActionSec=0
EOF
  systemctl restart systemd-logind || true
  ok "sleep/suspend masked"
}

hm_appliance_linger() {
  is_root || die "hm_appliance_linger needs root"
  local u
  u="$(target_user)"
  loginctl enable-linger "$u"
  ok "linger enabled for ${u}"
}

hm_appliance_wifi_powersave_off() {
  is_root || die "needs root"
  mkdir -p /etc/NetworkManager/conf.d
  cat >/etc/NetworkManager/conf.d/00-mediahub-wifi-powersave.conf <<'EOF'
[connection]
wifi.powersave = 2
EOF
  systemctl reload NetworkManager 2>/dev/null || true
  ok "wifi powersave off (if NetworkManager present)"
}

hm_appliance_presonus_udev() {
  is_root || die "needs root"
  # Optional pro-audio: only install if requested (HM_AUDIO_PRO=1)
  if [[ "${HM_AUDIO_PRO:-0}" != "1" ]]; then
    log "skip PreSonus udev (set HM_AUDIO_PRO=1 to enable)"
    return 0
  fi
  cat >/etc/udev/rules.d/99-presonus-1810c-autosuspend.rules <<'EOF'
ACTION=="add", SUBSYSTEM=="usb", ATTR{idVendor}=="194f", ATTR{idProduct}=="010c", TEST=="power/control", ATTR{power/control}="on"
ACTION=="add", SUBSYSTEM=="usb", ATTR{idVendor}=="194f", ATTR{idProduct}=="010c", TEST=="power/autosuspend", ATTR{power/autosuspend}="-1"
EOF
  udevadm control --reload-rules
  udevadm trigger --subsystem-match=usb || true
  ok "PreSonus 1810c autosuspend disabled"
}
