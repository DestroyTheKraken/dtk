#!/usr/bin/env bash
# Recommend / validate base OS for Sovereign Media Hub.
# shellcheck source=common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

hm_os_report() {
  if [[ -f /etc/os-release ]]; then
    # shellcheck disable=SC1091
    . /etc/os-release
    log "OS: ${PRETTY_NAME:-unknown} (${ID:-?} ${VERSION_ID:-?})"
  else
    warn "No /etc/os-release"
  fi
  log "Kernel: $(uname -r)"
  log "Desktop session hints: DESKTOP_SESSION=${DESKTOP_SESSION:-} XDG_CURRENT_DESKTOP=${XDG_CURRENT_DESKTOP:-}"
}

# Customer default: Ubuntu Desktop or Kubuntu 24.04/26.04 LTS.
# Ubuntu Studio is OPTIONAL (pro audio / low-latency) — not required for media hub.
hm_os_recommend() {
  cat <<'EOF'

=== Base OS recommendation (VTS / customer installs) ===

  RECOMMENDED (default product image)
    • Ubuntu Desktop 26.04 LTS  — GNOME, widest support
    • Kubuntu 26.04 LTS         — Plasma (matches HickMedia entertainment desktop)

  ACCEPTABLE
    • Ubuntu 24.04 LTS (noble) if customer already standardized on it

  OPTIONAL (only if customer has pro audio interface / low-latency needs)
    • Ubuntu Studio 26.04 — PipeWire/JACK tooling, larger footprint
      NOT required for Jellyfin + browser + RetroArch living-room hub.

  AVOID for customer media hubs
    • Minimal server-only with no desktop (unless pure headless Jellyfin server profile)
    • Rolling distros without LTS commitment

  Profiles:
    media-client   → desktop + Firefox + Jellyfin Desktop/browser + optional RetroArch
    media-server   → Docker Jellyfin + media dirs (desktop optional)
    full-hub       → client + server + appliance (no-sleep) + RetroArch defaults

EOF
}

hm_os_is_ubuntu_family() {
  [[ -f /etc/os-release ]] || return 1
  # shellcheck disable=SC1091
  . /etc/os-release
  [[ "${ID:-}" == "ubuntu" || "${ID_LIKE:-}" == *ubuntu* || "${ID_LIKE:-}" == *debian* ]]
}
