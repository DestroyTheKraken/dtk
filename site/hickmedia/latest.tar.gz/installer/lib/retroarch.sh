#!/usr/bin/env bash
# RetroArch entertainment defaults (optional profile).
# shellcheck source=common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

hm_retroarch_defaults() {
  local home ra cfg
  home="$(target_home)"
  ra="${home}/.config/retroarch"
  cfg="${ra}/retroarch.cfg"
  run_as_user mkdir -p \
    "${ra}/playlists" \
    "${ra}/thumbnails" \
    "${ra}/autoconfig/udev" \
    "${ra}/overlays" \
    "${ra}/database/rdb" \
    "${home}/ROMs"

  if [[ ! -f "$cfg" ]]; then
    # Generate a minimal cfg if RetroArch never launched
    if command -v retroarch >/dev/null 2>&1; then
      run_as_user retroarch --verbose --menu 2>/dev/null &
      sleep 1
      pkill -x retroarch 2>/dev/null || true
    fi
    run_as_user touch "$cfg"
  fi

  # Apply product defaults into existing cfg
  local tmp
  tmp="$(mktemp)"
  run_as_user cat "$cfg" >"$tmp" 2>/dev/null || true
  set_kv "$tmp" input_driver "udev"
  set_kv "$tmp" input_joypad_driver "udev"
  set_kv "$tmp" input_autodetect_enable "true"
  set_kv "$tmp" input_max_users "4"
  set_kv "$tmp" menu_driver "ozone"
  set_kv "$tmp" menu_thumbnails "3"
  set_kv "$tmp" menu_left_thumbnails "1"
  set_kv "$tmp" network_on_demand_thumbnails "true"
  set_kv "$tmp" thumbnails_directory "${ra}/thumbnails"
  set_kv "$tmp" content_database_path "${ra}/database/rdb"
  set_kv "$tmp" playlist_directory "${ra}/playlists"
  # Hotkeys: Select+Start = close content
  set_kv "$tmp" input_enable_hotkey_btn "6"
  set_kv "$tmp" input_close_content_btn "7"
  set_kv "$tmp" input_menu_toggle_btn "8"
  set_kv "$tmp" input_menu_toggle "f1"
  set_kv "$tmp" input_menu_toggle_gamepad_combo "4"
  set_kv "$tmp" input_exit_emulator "escape"
  set_kv "$tmp" quit_on_close_content "0"
  set_kv "$tmp" input_player1_analog_dpad_mode "1"
  set_kv "$tmp" input_player2_analog_dpad_mode "1"
  set_kv "$tmp" all_users_control_menu "true"
  # Overlay off by default for customers (enable after bezel pack)
  set_kv "$tmp" input_overlay_enable "false"
  set_kv "$tmp" input_overlay_hide_in_menu "true"

  install -o "$(target_user)" -g "$(id -gn "$(target_user)")" -m 644 "$tmp" "$cfg" 2>/dev/null || \
    run_as_user cp "$tmp" "$cfg"
  rm -f "$tmp"

  # ROM layout README
  run_as_user tee "${home}/ROMs/README.md" >/dev/null <<'EOF'
# ROMs layout (customer)

Place legally obtained ROMs in:

- `nes/`
- `snes/`
- `megadrive/` (Genesis)
- `n64/`

Then build playlists:

```bash
bash /opt/mediahub/scripts/build-retroarch-playlists.sh
# or from a cloned HickMedia tree:
bash ~/HickMedia/scripts/build-retroarch-playlists.sh
```

Art/metadata:

```bash
python3 ~/HickMedia/scripts/scrape-libretro-media.py
```
EOF

  # Chain optional product scripts if present in repo
  local scripts="${HM_REPO_ROOT}/scripts"
  if [[ -x "${scripts}/configure-8bitdo-dual.sh" ]]; then
    run_as_user bash "${scripts}/configure-8bitdo-dual.sh" || warn "8bitdo dual config failed"
  fi

  ok "RetroArch defaults written to ${cfg}"
}
