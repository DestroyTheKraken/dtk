#!/usr/bin/env bash
# ESSENTIAL pro audio for Sovereign Media Hub.
# Movies + Music + Gaming → high-quality path through a USB audio interface → speakers.
# shellcheck source=common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

hm_audio_apt_pro() {
  is_root || die "hm_audio_apt_pro needs root"
  export DEBIAN_FRONTEND=noninteractive
  log "install pro audio stack (PipeWire + tools)"
  apt-get install -y \
    pipewire pipewire-pulse pipewire-alsa wireplumber \
    pipewire-audio-client-libraries \
    libspa-0.2-bluetooth \
    libspa-0.2-jack \
    pulseaudio-utils \
    pavucontrol \
    qpwgraph \
    alsa-utils \
    rtkit \
    || warn "some audio packages missing"

  # Optional Studio helpers if available (never require full ubuntustudio-desktop)
  for pkg in ubuntustudio-pipewire-config jackd2; do
    if apt-cache show "$pkg" >/dev/null 2>&1; then
      apt-get install -y "$pkg" || true
    fi
  done

  local u
  u="$(target_user)"
  usermod -aG audio,realtime "$u" 2>/dev/null || usermod -aG audio "$u" || true
  # rtkit/limits for low-latency
  if [[ -d /etc/security/limits.d ]]; then
    cat >/etc/security/limits.d/99-mediahub-audio.conf <<EOF
@audio   -  rtprio     95
@audio   -  memlock    unlimited
${u}     -  rtprio     95
${u}     -  memlock    unlimited
EOF
  fi
  ok "pro audio packages + ${u} in group audio"
}

hm_audio_udev_interfaces() {
  is_root || die "needs root"
  log "udev: disable USB autosuspend for common pro interfaces"
  cat >/etc/udev/rules.d/99-mediahub-audio-interfaces.rules <<'EOF'
# PreSonus Studio 1810c
ACTION=="add", SUBSYSTEM=="usb", ATTR{idVendor}=="194f", ATTR{idProduct}=="010c", TEST=="power/control", ATTR{power/control}="on"
ACTION=="add", SUBSYSTEM=="usb", ATTR{idVendor}=="194f", ATTR{idProduct}=="010c", TEST=="power/autosuspend", ATTR{power/autosuspend}="-1"
# Focusrite Scarlett family (common customer interface)
ACTION=="add", SUBSYSTEM=="usb", ATTR{idVendor}=="1235", TEST=="power/control", ATTR{power/control}="on"
ACTION=="add", SUBSYSTEM=="usb", ATTR{idVendor}=="1235", TEST=="power/autosuspend", ATTR{power/autosuspend}="-1"
# Generic: keep USB audio powered (class 01)
ACTION=="add", SUBSYSTEM=="usb", ATTR{bInterfaceClass}=="01", TEST=="power/control", ATTR{power/control}="on"
EOF
  udevadm control --reload-rules
  udevadm trigger --subsystem-match=usb || true
  ok "audio interface udev rules installed"
}

hm_audio_apply_user_stack() {
  local home root
  home="$(target_home)"
  root="${HM_REPO_ROOT}"

  log "install PipeWire / WirePlumber / profile scripts for $(target_user)"
  run_as_user mkdir -p \
    "${home}/.config/pipewire/pipewire.conf.d" \
    "${home}/.config/pipewire/pipewire-pulse.conf.d" \
    "${home}/.config/wireplumber/wireplumber.conf.d" \
    "${home}/.config/systemd/user" \
    "${home}/.local/share/applications" \
    "${home}/bin"

  # Clock + RT + pulse HQ
  if [[ -d "${root}/audio/pipewire.conf.d" ]]; then
    run_as_user cp -a "${root}/audio/pipewire.conf.d/." "${home}/.config/pipewire/pipewire.conf.d/"
  fi
  if [[ -d "${root}/audio/pipewire-pulse.conf.d" ]]; then
    run_as_user cp -a "${root}/audio/pipewire-pulse.conf.d/." "${home}/.config/pipewire/pipewire-pulse.conf.d/"
  fi
  # WP 0.5 conf (not legacy lua-only)
  if [[ -d "${root}/audio/wireplumber/wireplumber.conf.d" ]]; then
    run_as_user cp -a "${root}/audio/wireplumber/wireplumber.conf.d/." \
      "${home}/.config/wireplumber/wireplumber.conf.d/"
  fi

  # Scripts
  for s in ht-audio-route.sh ht-audio-profile.sh ht-gaming-quantum.sh health-check.sh; do
    if [[ -f "${root}/scripts/${s}" ]]; then
      run_as_user install -m 755 "${root}/scripts/${s}" "${home}/bin/${s}"
    fi
  done

  # User systemd unit
  run_as_user tee "${home}/.config/systemd/user/ht-audio-route.service" >/dev/null <<EOF
[Unit]
Description=Media Hub pro-audio routes (interface → speakers)
After=pipewire.service wireplumber.service
Wants=pipewire.service wireplumber.service

[Service]
Type=oneshot
ExecStart=${home}/bin/ht-audio-route.sh
RemainAfterExit=yes

[Install]
WantedBy=default.target
EOF

  # Desktop profile switchers
  for prof in movies music gaming; do
    local name label
    case "$prof" in
      movies) name="Audio Movies"; label="movies" ;;
      music)  name="Audio Music";  label="music" ;;
      gaming) name="Audio Gaming"; label="gaming" ;;
    esac
    run_as_user tee "${home}/.local/share/applications/mediahub-audio-${prof}.desktop" >/dev/null <<EOF
[Desktop Entry]
Type=Application
Name=${name}
Comment=PipeWire profile → pro interface @ 48 kHz
Exec=${home}/bin/ht-audio-profile.sh ${label}
Icon=audio-card
Terminal=false
Categories=AudioVideo;Audio;
EOF
  done

  # Disable Ardour 24/7 if present (offline use only)
  run_as_user mkdir -p "${home}/.config/autostart"
  run_as_user tee "${home}/.config/autostart/home-theater-mixer.desktop" >/dev/null <<'EOF'
[Desktop Entry]
Type=Application
Name=Home Theater Mixer (DISABLED — use PipeWire)
Exec=/bin/true
Hidden=true
X-GNOME-Autostart-enabled=false
EOF

  # Enable unit if user session bus available
  if run_as_user systemctl --user daemon-reload 2>/dev/null; then
    run_as_user systemctl --user enable ht-audio-route.service || true
    run_as_user systemctl --user restart pipewire pipewire-pulse wireplumber 2>/dev/null || true
    sleep 2
    run_as_user systemctl --user start ht-audio-route.service || true
  else
    warn "user systemd not reachable now — enable after login: systemctl --user enable --now ht-audio-route.service"
  fi

  ok "pro audio user stack applied (Movies/Music/Gaming profiles)"
}

hm_audio_pro_essential() {
  # Always called for product installs
  hm_audio_apt_pro
  hm_audio_udev_interfaces
  hm_audio_apply_user_stack
  log "Pro audio ESSENTIAL path complete: Apps → PipeWire@48k → USB interface → speakers"
}
