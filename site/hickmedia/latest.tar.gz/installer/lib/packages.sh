#!/usr/bin/env bash
# Package installs for Sovereign Media Hub profiles.
# shellcheck source=common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

hm_apt_base() {
  is_root || die "hm_apt_base needs root"
  export DEBIAN_FRONTEND=noninteractive
  log "apt update + base packages"
  apt-get update -y
  apt-get install -y \
    curl ca-certificates gnupg apt-transport-https \
    flatpak \
    pipewire pipewire-pulse wireplumber \
    pavucontrol \
    openssh-server \
    rsync wget git \
    smartmontools usbutils \
    fonts-noto-core \
    xdg-utils \
    firefox || apt-get install -y firefox-esr || true

  # Browser alternative only if customer wants Chromium later — not default
  # Do NOT pull Ubuntu Studio metapackages on customer installs.
}

hm_apt_retro() {
  is_root || die "hm_apt_retro needs root"
  export DEBIAN_FRONTEND=noninteractive
  if apt-cache show retroarch >/dev/null 2>&1; then
    apt-get install -y retroarch || warn "retroarch apt failed"
  else
    warn "no apt retroarch — install Flatpak later if needed"
  fi
  if apt-cache show retroarch-joypad-autoconfig >/dev/null 2>&1; then
    apt-get install -y retroarch-joypad-autoconfig || true
  fi
}

hm_apt_docker() {
  is_root || die "hm_apt_docker needs root"
  export DEBIAN_FRONTEND=noninteractive
  apt-get install -y docker.io docker-compose-v2
  local u
  u="$(target_user)"
  usermod -aG docker "$u" || true
  systemctl enable --now docker
  ok "docker enabled; user ${u} in group docker (re-login required for group)"
}

hm_flatpak_user() {
  local u home
  u="$(target_user)"
  home="$(target_home)"
  log "Flatpak remotes + Jellyfin Desktop for ${u}"
  run_as_user flatpak remote-add --user --if-not-exists flathub \
    https://dl.flathub.org/repo/flathub.flatpakrepo || true
  run_as_user flatpak install --user -y flathub org.jellyfin.JellyfinDesktop || \
    warn "Jellyfin Desktop flatpak install failed (browser client still works)"
}

# Optional: remove common Studio bloat if present on a converted Studio box
hm_suggest_studio_trim() {
  if dpkg -l ubuntustudio-desktop-core 2>/dev/null | grep -q '^ii'; then
    warn "Ubuntu Studio desktop metapackage present."
    warn "For customer hubs prefer Kubuntu/Ubuntu Desktop. Studio is optional for pro audio only."
    warn "Do NOT mass-purge Studio packages on a live family hub without explicit approval."
  fi
}
