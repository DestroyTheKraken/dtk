#!/usr/bin/env bash
# Desktop entertainment defaults: Firefox + Brave Search, launchers.
# shellcheck source=common.sh
source "$(dirname "${BASH_SOURCE[0]}")/common.sh"

hm_desktop_firefox_default_browser() {
  is_root || true
  local u home
  u="$(target_user)"
  home="$(target_home)"

  log "Set Firefox as default browser for ${u}"
  if command -v update-alternatives >/dev/null 2>&1 && is_root; then
    if [[ -x /usr/bin/firefox ]]; then
      update-alternatives --set x-www-browser /usr/bin/firefox 2>/dev/null || \
        update-alternatives --install /usr/bin/x-www-browser x-www-browser /usr/bin/firefox 100 || true
    fi
  fi

  # Per-user MIME / xdg
  run_as_user mkdir -p "${home}/.config"
  run_as_user xdg-settings set default-web-browser firefox.desktop 2>/dev/null || \
    run_as_user xdg-settings set default-web-browser firefox_firefox.desktop 2>/dev/null || \
    warn "xdg-settings default browser failed (set manually in desktop settings)"

  # Also write mimeapps for GNOME/KDE
  local mime="${home}/.config/mimeapps.list"
  if [[ ! -f "$mime" ]] || ! grep -q 'x-scheme-handler/http=firefox' "$mime" 2>/dev/null; then
    run_as_user bash -c "cat >>'${mime}' <<'EOF'

[Default Applications]
x-scheme-handler/http=firefox.desktop
x-scheme-handler/https=firefox.desktop
text/html=firefox.desktop
EOF"
  fi
  ok "default browser → Firefox"
}

hm_desktop_brave_search() {
  local u home policies_sys policies_user
  u="$(target_user)"
  home="$(target_home)"

  log "Configure Brave Search as default search (Firefox policies + user pref)"

  # System-wide Firefox policy (works for deb + many snaps via /etc/firefox/policies)
  if is_root; then
    mkdir -p /etc/firefox/policies
    cat >/etc/firefox/policies/policies.json <<'EOF'
{
  "policies": {
    "SearchEngines": {
      "Default": "Brave",
      "PreventInstalls": false,
      "Add": [
        {
          "Name": "Brave",
          "URLTemplate": "https://search.brave.com/search?q={searchTerms}",
          "Method": "GET",
          "IconURL": "https://cdn.search.brave.com/serp/favicon.ico",
          "Alias": "brave",
          "Description": "Brave Search",
          "SuggestURLTemplate": "https://search.brave.com/api/suggest?q={searchTerms}"
        }
      ]
    },
    "DontCheckDefaultBrowser": true,
    "DisableTelemetry": true,
    "Homepage": {
      "URL": "https://search.brave.com/",
      "StartPage": "homepage"
    }
  }
}
EOF
    ok "wrote /etc/firefox/policies/policies.json"
  else
    warn "not root — skip system Firefox policies; writing user defaults only"
  fi

  # User distribution search plugins / prefs for snap firefox
  local dist="${home}/.mozilla/firefox"
  run_as_user mkdir -p "${home}/.mozilla/firefox" "${home}/snap/firefox/common/.mozilla/firefox" 2>/dev/null || true

  # user.js template applied to any existing profiles
  local userjs_snippet
  userjs_snippet='
// Sovereign Media Hub — Brave Search defaults
user_pref("browser.search.defaultenginename", "Brave");
user_pref("browser.search.selectedEngine", "Brave");
user_pref("browser.urlbar.placeholderName", "Brave");
user_pref("browser.startup.homepage", "https://search.brave.com/");
user_pref("browser.newtabpage.enabled", true);
'

  # Write a ready-to-merge fragment for VTS
  local frag_dir="${home}/.config/mediahub"
  run_as_user mkdir -p "$frag_dir"
  printf '%s\n' "$userjs_snippet" | run_as_user tee "${frag_dir}/firefox-user.js.fragment" >/dev/null

  # Best-effort: inject into existing profile dirs
  for base in "${home}/.mozilla/firefox" "${home}/snap/firefox/common/.mozilla/firefox"; do
    [[ -d "$base" ]] || continue
    while IFS= read -r -d '' prefdir; do
      local ujs="${prefdir}/user.js"
      if [[ -f "$ujs" ]] && grep -q 'Sovereign Media Hub' "$ujs" 2>/dev/null; then
        continue
      fi
      printf '%s\n' "$userjs_snippet" | run_as_user tee -a "$ujs" >/dev/null || true
      log "patched ${ujs}"
    done < <(find "$base" -maxdepth 1 -type d -name '*.default*' -print0 2>/dev/null || true)
  done
  ok "Brave Search defaults staged"
}

hm_desktop_launchers() {
  local home jf_url
  home="$(target_home)"
  jf_url="${HM_JELLYFIN_URL:-http://127.0.0.1:8096}"
  run_as_user mkdir -p "${home}/.local/share/applications" "${home}/bin"

  # Watch (Jellyfin) — prefer desktop app, fallback browser
  run_as_user tee "${home}/.local/share/applications/mediahub-watch.desktop" >/dev/null <<EOF
[Desktop Entry]
Type=Application
Name=Watch (Jellyfin)
Comment=Private on-prem media library
Exec=sh -c 'flatpak run org.jellyfin.JellyfinDesktop 2>/dev/null || xdg-open ${jf_url}'
Icon=org.jellyfin.JellyfinDesktop
Terminal=false
Categories=AudioVideo;Video;
EOF

  # Browser shortcut with Brave Search homepage
  run_as_user tee "${home}/.local/share/applications/mediahub-browser.desktop" >/dev/null <<'EOF'
[Desktop Entry]
Type=Application
Name=Web (Firefox)
Comment=Default browser — Brave Search
Exec=firefox https://search.brave.com/
Icon=firefox
Terminal=false
Categories=Network;WebBrowser;
EOF

  if command -v retroarch >/dev/null 2>&1 || [[ -x "${home}/bin/launch-retroarch.sh" ]]; then
    run_as_user tee "${home}/.local/share/applications/mediahub-play.desktop" >/dev/null <<'EOF'
[Desktop Entry]
Type=Application
Name=Play (RetroArch)
Comment=Retro games
Exec=sh -c '$HOME/bin/launch-retroarch.sh 2>/dev/null || retroarch --menu'
Icon=retroarch
Terminal=false
Categories=Game;
EOF
  fi

  # Portable launch helpers
  run_as_user tee "${home}/bin/launch-watch.sh" >/dev/null <<EOF
#!/usr/bin/env bash
set -euo pipefail
if flatpak info org.jellyfin.JellyfinDesktop >/dev/null 2>&1; then
  exec flatpak run org.jellyfin.JellyfinDesktop
fi
exec xdg-open "${jf_url}"
EOF
  run_as_user chmod +x "${home}/bin/launch-watch.sh"

  if command -v retroarch >/dev/null 2>&1; then
    run_as_user tee "${home}/bin/launch-retroarch.sh" >/dev/null <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export DBUS_SESSION_BUS_ADDRESS="${DBUS_SESSION_BUS_ADDRESS:-unix:path=${XDG_RUNTIME_DIR}/bus}"
if [[ -z "${WAYLAND_DISPLAY:-}" ]]; then
  [[ -S ${XDG_RUNTIME_DIR}/wayland-0 ]] && export WAYLAND_DISPLAY=wayland-0
  [[ -S ${XDG_RUNTIME_DIR}/wayland-1 ]] && export WAYLAND_DISPLAY=wayland-1
fi
export SDL_JOYSTICK_HIDAPI=1
exec retroarch -c "$HOME/.config/retroarch/retroarch.cfg" --menu "$@"
EOF
    run_as_user chmod +x "${home}/bin/launch-retroarch.sh"
  fi

  ok "desktop launchers installed under ${home}/.local/share/applications"
}
