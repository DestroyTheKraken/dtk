#!/usr/bin/env bash
# Shared helpers for the Sovereign Media Hub installer.
# shellcheck disable=SC2034
set -euo pipefail

HM_INSTALLER_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HM_REPO_ROOT="$(cd "${HM_INSTALLER_ROOT}/.." && pwd)"
HM_STATE_DIR="${HM_STATE_DIR:-${HM_INSTALLER_ROOT}/.state}"
HM_LOG="${HM_LOG:-${HM_STATE_DIR}/install-$(date +%Y%m%d-%H%M%S).log}"

mkdir -p "${HM_STATE_DIR}"

log()  { echo "[$(date +%H:%M:%S)] $*" | tee -a "${HM_LOG}"; }
ok()   { log "OK  $*"; }
warn() { log "WARN $*"; }
die()  { log "ERR $*"; exit 1; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }

is_root() { [[ "$(id -u)" -eq 0 ]]; }

target_user() {
  if [[ -n "${SUDO_USER:-}" && "${SUDO_USER}" != "root" ]]; then
    echo "${SUDO_USER}"
  elif [[ -n "${HM_USER:-}" ]]; then
    echo "${HM_USER}"
  else
    id -un
  fi
}

target_home() {
  local u
  u="$(target_user)"
  getent passwd "$u" | cut -d: -f6
}

run_as_user() {
  local u
  u="$(target_user)"
  if [[ "$(id -un)" == "$u" ]]; then
    "$@"
  else
    sudo -u "$u" -- "$@"
  fi
}

# Write or replace KEY = "VAL" in a RetroArch-style cfg
set_kv() {
  local file="$1" key="$2" val="$3"
  mkdir -p "$(dirname "$file")"
  touch "$file"
  if grep -qE "^${key} *=" "$file" 2>/dev/null; then
    sed -i "s|^${key} *=.*|${key} = \"${val}\"|" "$file"
  else
    echo "${key} = \"${val}\"" >>"$file"
  fi
}

confirm() {
  local prompt="${1:-Continue?}"
  if [[ "${HM_YES:-0}" == "1" ]]; then
    return 0
  fi
  read -r -p "${prompt} [y/N] " ans
  [[ "${ans}" =~ ^[Yy]$ ]]
}
