-- Prefer PreSonus Studio 1810c as default sink/source (HickMedia)
-- Installed to ~/.config/wireplumber/wireplumber.conf.d/

alsa_monitor.rules = {
  {
    matches = {
      {
        { "device.name", "matches", "alsa_card.usb-PreSonus_Studio_1810c*" },
      },
    },
    apply_properties = {
      ["api.alsa.period-size"]   = 256,
      ["api.alsa.headroom"]      = 1024,
      ["session.suspend-timeout-seconds"] = 0,
    },
  },
}
