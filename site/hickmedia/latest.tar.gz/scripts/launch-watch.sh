#!/usr/bin/env bash
# Fullscreen Chromium kiosk → Jellyfin /mov
set -euo pipefail
URL="${HICKMEDIA_MOV_URL:-https://hickmedia.taile52ad9.ts.net/mov}"
# Prefer chromium, then google-chrome, then firefox
for bin in chromium-browser chromium google-chrome-stable google-chrome firefox; do
  if command -v "$bin" >/dev/null 2>&1; then
    exec "$bin" --app="$URL" --start-fullscreen --no-first-run --disable-session-crashed-bubble \
      --autoplay-policy=no-user-gesture-required "$@"
  fi
done
echo "No chromium/chrome/firefox found. Install chromium:"
echo "  sudo apt install -y chromium-browser || sudo apt install -y chromium"
exit 1
