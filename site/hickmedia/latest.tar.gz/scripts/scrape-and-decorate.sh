#!/usr/bin/env bash
# One-shot: scrape artwork + metadata for all playlists, enable retro TV bezels.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
LOG="${ROOT}/logs/scrape-media-$(date +%Y%m%d-%H%M%S).log"
mkdir -p "${ROOT}/logs"

echo "Logging to $LOG"
{
  echo "=== $(date -Is) scrape-and-decorate start ==="
  bash "${ROOT}/scripts/configure-retro-tv-bezels.sh"
  python3 "${ROOT}/scripts/scrape-libretro-media.py" --workers 12 "$@"
  echo "=== $(date -Is) done ==="
} 2>&1 | tee "$LOG"

echo
echo "Log: $LOG"
echo "Coverage re-check:"
python3 "${ROOT}/scripts/scrape-libretro-media.py" --report-only
