#!/usr/bin/env bash
# Home Theater hardware path via PipeWire.
# Goals:
#   1) Pro USB audio interface = default sink/source (speakers / monitors)
#   2) Lock 48 kHz graph for Movies + Music + Gaming
#   3) On PreSonus Studio 1810c: multichannel capture pairs → playback 1/2 (unity HW mix)
#
# Replaces 24/7 Ardour. Optional Ardour offline only.
set -euo pipefail

LOG_TAG="ht-audio-route"
log() { echo "[$LOG_TAG] $*"; logger -t "$LOG_TAG" "$*" 2>/dev/null || true; }

# Match common pro interfaces (extend as needed)
IFACE_RE="${HM_AUDIO_IFACE_RE:-PreSonus_Studio_1810c|Focusrite|Scarlett|Behringer|UMC|MOTU|AudioBox|USB_Audio|usb-}"

wait_iface() {
  local i
  for i in $(seq 1 60); do
    if pw-link -i 2>/dev/null | grep -qiE "$IFACE_RE"; then
      return 0
    fi
    # Also accept any USB ALSA sink present in wpctl
    if wpctl status 2>/dev/null | grep -qiE 'usb-.*Audio|PreSonus|Focusrite|Behringer'; then
      return 0
    fi
    sleep 1
  done
  return 1
}

list_ports() {
  local kind="$1" re="$2"
  if [[ "$kind" == out ]]; then
    pw-link -o 2>/dev/null | grep -iE "$re" || true
  else
    pw-link -i 2>/dev/null | grep -iE "$re" || true
  fi
}

link_ok() {
  local a="$1" b="$2"
  [[ -n "$a" && -n "$b" ]] || return 1
  pw-link -d "$a" "$b" 2>/dev/null || true
  if pw-link "$a" "$b" 2>/dev/null; then
    log "linked $a -> $b"
    return 0
  fi
  log "FAILED link $a -> $b"
  return 1
}

set_defaults_and_clock() {
  # Movies/Music/Gaming share locked 48 kHz; hub quantum 1024
  if [[ -x "${HOME}/bin/ht-audio-profile.sh" ]]; then
    "${HOME}/bin/ht-audio-profile.sh" hub || true
  else
    pw-metadata -n settings 0 clock.force-rate 48000 2>/dev/null || true
    pw-metadata -n settings 0 clock.force-quantum 1024 2>/dev/null || true
    local sid src
    sid=$(wpctl status 2>/dev/null | sed -n '/Sinks:/,/Sources:/p' \
      | grep -iE 'usb|PreSonus|Focusrite|Behringer|Studio' | grep -vE 'hdmi|HDMI' \
      | head -1 | grep -oE '[0-9]+' | head -1 || true)
    [[ -n "${sid:-}" ]] && wpctl set-default "$sid" 2>/dev/null && log "default sink id=$sid"
    src=$(wpctl status 2>/dev/null | sed -n '/Sources:/,/Filters/p' \
      | grep -iE 'usb|PreSonus|Focusrite|Behringer|Studio' \
      | head -1 | grep -oE '[0-9]+' | head -1 || true)
    [[ -n "${src:-}" ]] && wpctl set-default "$src" 2>/dev/null && log "default source id=$src"
  fi
  log "clock locked 48 kHz (pro interface preferred for speakers)"
}

# --- PreSonus 1810c multichannel unity mix (family HW path) ---

resolve_playback_lr() {
  local fl fr
  fl=$(list_ports in 'PreSonus_Studio_1810c.*playback_FL' | head -1)
  fr=$(list_ports in 'PreSonus_Studio_1810c.*playback_FR' | head -1)
  if [[ -z "$fl" ]]; then
    fl=$(list_ports in 'PreSonus_Studio_1810c.*:playback_1$' | head -1)
  fi
  if [[ -z "$fr" ]]; then
    fr=$(list_ports in 'PreSonus_Studio_1810c.*:playback_2$' | head -1)
  fi
  printf '%s\n%s\n' "$fl" "$fr"
}

resolve_capture_pair() {
  local pair="$1"
  local a b
  local aux_l=$((pair * 2))
  local aux_r=$((pair * 2 + 1))
  a=$(list_ports out "PreSonus_Studio_1810c.*capture_AUX${aux_l}$" | head -1)
  b=$(list_ports out "PreSonus_Studio_1810c.*capture_AUX${aux_r}$" | head -1)
  if [[ -z "$a" ]]; then
    local c_l=$((pair * 2 + 1))
    local c_r=$((pair * 2 + 2))
    a=$(list_ports out "PreSonus_Studio_1810c.*:capture_${c_l}$" | head -1)
    b=$(list_ports out "PreSonus_Studio_1810c.*:capture_${c_r}$" | head -1)
  fi
  printf '%s\n%s\n' "$a" "$b"
}

route_1810c_hw_mix() {
  pw-link -o 2>/dev/null | grep -qi 'PreSonus_Studio_1810c' || return 1

  local fl fr
  mapfile -t lr < <(resolve_playback_lr)
  fl=${lr[0]:-}
  fr=${lr[1]:-}
  if [[ -z "$fl" || -z "$fr" ]]; then
    log "1810c: could not resolve FL/FR playback"
    return 1
  fi
  log "1810c HW mix → L=$fl R=$fr"

  local pair left right
  for pair in 0 1 2 3 4 5; do
    mapfile -t ch < <(resolve_capture_pair "$pair")
    left=${ch[0]:-}
    right=${ch[1]:-}
    if [[ -n "$left" && -n "$right" ]]; then
      link_ok "$left" "$fl" || true
      link_ok "$right" "$fr" || true
    else
      log "skip pair $pair"
    fi
  done
  log "1810c HW mix complete"
  return 0
}

main() {
  command -v pw-link >/dev/null || { log "pw-link missing (install pipewire-bin)"; exit 1; }

  log "waiting for pro audio interface..."
  if ! wait_iface; then
    log "WARN: no USB pro interface detected — desktop audio may use onboard"
    set_defaults_and_clock
    exit 0
  fi

  set_defaults_and_clock
  sleep 1

  # Device-specific multichannel mix when 1810c present
  if route_1810c_hw_mix; then
    :
  else
    log "generic interface: defaults only (no multichannel HW mix)"
  fi

  log "routing complete — all app audio should go: Apps → PipeWire → Interface → Speakers"
  pw-link -l 2>/dev/null | grep -iE 'capture_|playback_' | head -40 || true
}

main "$@"
