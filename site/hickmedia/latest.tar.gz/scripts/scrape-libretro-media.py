#!/usr/bin/env python3
"""
Download box art, title screens, and in-game snaps for every playlist entry
from the official Libretro thumbnail server (https://thumbnails.libretro.com).

Also installs system RDB metadata from libretro-database when requested.

Usage (on hickmedia):
  python3 ~/HickMedia/scripts/scrape-libretro-media.py
  python3 ~/HickMedia/scripts/scrape-libretro-media.py --kinds boxarts titles snaps
  python3 ~/HickMedia/scripts/scrape-libretro-media.py --workers 12
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

HOME = Path.home()
RA = HOME / ".config" / "retroarch"
PLAY_DIR = RA / "playlists"
THUMB_DIR = RA / "thumbnails"
DB_DIR = RA / "database" / "rdb"
LOG_DIR = HOME / "HickMedia" / "logs"

# Invalid filename chars per libretro thumbnail docs
INVALID = set('&*/:`<>?\\|"')

SYSTEMS = {
    "Nintendo - Nintendo Entertainment System.lpl": "Nintendo - Nintendo Entertainment System",
    "Nintendo - Super Nintendo Entertainment System.lpl": "Nintendo - Super Nintendo Entertainment System",
    "Nintendo - Nintendo 64.lpl": "Nintendo - Nintendo 64",
    "Sega - Mega Drive - Genesis.lpl": "Sega - Mega Drive - Genesis",
}

KIND_MAP = {
    "boxarts": "Named_Boxarts",
    "titles": "Named_Titles",
    "snaps": "Named_Snaps",
    "logos": "Named_Logos",
}

# libretro-database RDB basenames (without .rdb)
RDB_NAMES = [
    "Nintendo - Nintendo Entertainment System",
    "Nintendo - Super Nintendo Entertainment System",
    "Nintendo - Nintendo 64",
    "Sega - Mega Drive - Genesis",
]

UA = "HickMedia-thumbnail-scraper/1.0 (+local; libretro-thumbnails client)"


def sanitize_thumb_name(label: str) -> str:
    """RetroArch thumbnail filename from playlist label."""
    name = label.strip()
    # Playlist sometimes keeps ROM extension on N64 labels
    for ext in (
        ".n64",
        ".z64",
        ".v64",
        ".nes",
        ".sfc",
        ".smc",
        ".md",
        ".gen",
        ".bin",
        ".zip",
        ".7z",
    ):
        if name.lower().endswith(ext):
            name = name[: -len(ext)]
    out = []
    for ch in name:
        out.append("_" if ch in INVALID else ch)
    return "".join(out)


def load_labels(lpl: Path) -> list[str]:
    data = json.loads(lpl.read_text(encoding="utf-8", errors="replace"))
    labels: list[str] = []
    for it in data.get("items") or []:
        lab = (it.get("label") or "").strip()
        if not lab:
            p = it.get("path") or ""
            lab = Path(p).stem
            # strip double extensions like .n64.zip
            if lab.lower().endswith((".n64", ".z64", ".v64", ".nes", ".sfc", ".smc", ".md", ".gen")):
                lab = Path(lab).stem
        if lab:
            labels.append(lab)
    # unique preserve order
    seen: set[str] = set()
    uniq: list[str] = []
    for lab in labels:
        if lab not in seen:
            seen.add(lab)
            uniq.append(lab)
    return uniq


def thumb_url(system: str, kind_dir: str, thumb_name: str) -> str:
    # server path segments must be percent-encoded; keep path separators
    base = "https://thumbnails.libretro.com"
    parts = [
        urllib.parse.quote(system, safe=""),
        urllib.parse.quote(kind_dir, safe=""),
        urllib.parse.quote(thumb_name + ".png", safe=""),
    ]
    return base + "/" + "/".join(parts)


def download_one(url: str, dest: Path, timeout: float = 30.0) -> str:
    """Return status: ok | skip | miss | err"""
    if dest.is_file() and dest.stat().st_size > 0:
        return "skip"
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_suffix(dest.suffix + ".part")
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            if resp.status != 200:
                return "miss"
            data = resp.read()
            if not data or len(data) < 32:
                return "miss"
            # reject HTML error pages
            if data[:15].lstrip().startswith(b"<!DOCTYPE") or data[:6].lstrip().startswith(b"<html"):
                return "miss"
            tmp.write_bytes(data)
            tmp.replace(dest)
            return "ok"
    except urllib.error.HTTPError as e:
        if e.code in (404, 410):
            return "miss"
        return f"err:{e.code}"
    except Exception as e:
        return f"err:{type(e).__name__}"


def scrape_system(
    system: str,
    labels: list[str],
    kinds: list[str],
    workers: int,
) -> dict[str, int]:
    stats = {k: 0 for k in ("ok", "skip", "miss", "err")}
    jobs: list[tuple[str, Path, str]] = []  # url, dest, kind
    for label in labels:
        tname = sanitize_thumb_name(label)
        for kind in kinds:
            kind_dir = KIND_MAP[kind]
            dest = THUMB_DIR / system / kind_dir / f"{tname}.png"
            # also keep a copy under original label if different (RA matches flexibly)
            url = thumb_url(system, kind_dir, tname)
            jobs.append((url, dest, kind))
            if tname != label and not any(c in label for c in INVALID):
                # original label path when only extension was stripped
                dest2 = THUMB_DIR / system / kind_dir / f"{label}.png"
                if dest2 != dest:
                    jobs.append((url, dest2, kind))

    print(f"\n=== {system} ===")
    print(f"labels={len(labels)} jobs={len(jobs)} kinds={kinds}")

    done = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = {ex.submit(download_one, u, d): (u, d) for u, d, _ in jobs}
        for fut in as_completed(futs):
            st = fut.result()
            key = st if st in stats else "err"
            stats[key] = stats.get(key, 0) + 1
            done += 1
            if done % 100 == 0 or done == len(jobs):
                print(
                    f"  progress {done}/{len(jobs)}  "
                    f"ok={stats['ok']} skip={stats['skip']} miss={stats['miss']} err={stats['err']}",
                    flush=True,
                )
    return stats


def install_rdb() -> None:
    """Shallow-clone libretro-database and copy the four system RDBs."""
    DB_DIR.mkdir(parents=True, exist_ok=True)
    print("\n=== Installing libretro RDB metadata ===")
    with tempfile.TemporaryDirectory(prefix="libretro-db-") as td:
        td_path = Path(td)
        repo = td_path / "libretro-database"
        print("cloning libretro-database (sparse rdb/)...")
        subprocess.run(
            [
                "git",
                "clone",
                "--depth",
                "1",
                "--filter=blob:none",
                "--sparse",
                "https://github.com/libretro/libretro-database.git",
                str(repo),
            ],
            check=True,
        )
        # Sparse-checkout the whole rdb directory (files, not treated as dirs)
        subprocess.run(
            ["git", "-C", str(repo), "sparse-checkout", "set", "--no-cone", "rdb"],
            check=True,
        )
        subprocess.run(["git", "-C", str(repo), "checkout"], check=False)
        rdb_root = repo / "rdb"
        if not rdb_root.is_dir():
            raise RuntimeError(f"rdb/ missing after sparse checkout: {repo}")
        for n in RDB_NAMES:
            src = rdb_root / f"{n}.rdb"
            if src.is_file():
                dest = DB_DIR / f"{n}.rdb"
                shutil.copy2(src, dest)
                print(f"  installed {dest} ({dest.stat().st_size} bytes)")
            else:
                print(f"  WARN: could not find RDB for {n} under {rdb_root}")
                # list a few for debug
                sample = sorted(rdb_root.glob("Nintendo*.rdb"))[:8]
                print(f"  sample Nintendo*.rdb: {[p.name for p in sample]}")
    print(f"RDB dir: {DB_DIR}")
    for p in sorted(DB_DIR.glob("*.rdb")):
        print(f"  {p.name} {p.stat().st_size}")


def coverage_report(kinds: list[str]) -> None:
    print("\n=== Coverage report ===")
    for lpl_name, system in SYSTEMS.items():
        lpl = PLAY_DIR / lpl_name
        if not lpl.is_file():
            print(f"{system}: missing playlist")
            continue
        labels = load_labels(lpl)
        print(f"\n{system}  ({len(labels)} games)")
        for kind in kinds:
            kind_dir = KIND_MAP[kind]
            d = THUMB_DIR / system / kind_dir
            have = 0
            for lab in labels:
                tname = sanitize_thumb_name(lab)
                if (d / f"{tname}.png").is_file() or (d / f"{lab}.png").is_file():
                    have += 1
            pct = (100.0 * have / len(labels)) if labels else 0.0
            print(f"  {kind:8s}: {have:4d}/{len(labels)}  ({pct:.1f}%)  dir={d}")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument(
        "--kinds",
        nargs="+",
        default=["boxarts", "titles", "snaps"],
        choices=list(KIND_MAP.keys()),
    )
    ap.add_argument("--workers", type=int, default=10)
    ap.add_argument("--no-rdb", action="store_true", help="Skip RDB metadata install")
    ap.add_argument("--rdb-only", action="store_true")
    ap.add_argument("--report-only", action="store_true")
    args = ap.parse_args()

    LOG_DIR.mkdir(parents=True, exist_ok=True)
    THUMB_DIR.mkdir(parents=True, exist_ok=True)

    if args.report_only:
        coverage_report(args.kinds)
        return 0

    if not args.no_rdb or args.rdb_only:
        try:
            install_rdb()
        except Exception as e:
            print(f"RDB install failed (non-fatal): {e}", file=sys.stderr)
            # fallback: try direct download of rdb from raw github if present in release
        if args.rdb_only:
            return 0

    totals = {k: 0 for k in ("ok", "skip", "miss", "err")}
    t0 = time.time()
    for lpl_name, system in SYSTEMS.items():
        lpl = PLAY_DIR / lpl_name
        if not lpl.is_file():
            print(f"skip missing playlist {lpl}")
            continue
        labels = load_labels(lpl)
        st = scrape_system(system, labels, args.kinds, args.workers)
        for k, v in st.items():
            totals[k] = totals.get(k, 0) + v

    elapsed = time.time() - t0
    print(
        f"\n=== DONE in {elapsed/60:.1f} min ===\n"
        f"ok={totals['ok']} skip={totals['skip']} miss={totals['miss']} err={totals['err']}"
    )
    coverage_report(args.kinds)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
