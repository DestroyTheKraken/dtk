#!/usr/bin/env bash
# Enable retro CRT TV bezels for in-game display on hickmedia RetroArch.
# Uses / enhances stock borders/tv-integer + optional Bezel Project system packs.
set -euo pipefail

RA="${HOME}/.config/retroarch"
CFG="${RA}/retroarch.cfg"
OV="${RA}/overlays"
BEZEL_DIR="${OV}/hickmedia-tv"
CONFIG_DIR="${RA}/config"
mkdir -p "$BEZEL_DIR" "$CONFIG_DIR" \
  "$CONFIG_DIR/Nestopia" \
  "$CONFIG_DIR/Mesen" \
  "$CONFIG_DIR/Snes9x" \
  "$CONFIG_DIR/bsnes" \
  "$CONFIG_DIR/Mupen64Plus-Next" \
  "$CONFIG_DIR/ParaLLEl N64" \
  "$CONFIG_DIR/Genesis Plus GX" \
  "$CONFIG_DIR/PicoDrive"

[[ -f "$CFG" ]] || { echo "missing $CFG"; exit 1; }

set_ra() {
  local key="$1" val="$2" file="${3:-$CFG}"
  if grep -qE "^${key} *=" "$file" 2>/dev/null; then
    sed -i "s|^${key} *=.*|${key} = \"${val}\"|" "$file"
  else
    echo "${key} = \"${val}\"" >>"$file"
  fi
}

# Prefer stock TV integer bezel if present
TV_CFG="${OV}/borders/tv-integer.cfg"
TV_PNG="${OV}/borders/img/tv-integer.png"
if [[ ! -f "$TV_CFG" || ! -f "$TV_PNG" ]]; then
  echo "WARN: stock tv-integer overlay missing — creating minimal CRT frame placeholder cfg"
fi

# Local copy with full opacity + slightly wider safe viewport for projector
cat >"${BEZEL_DIR}/crt-tv.cfg" <<EOF
overlays = 1
overlay0_overlay = ${TV_PNG:-img/tv-integer.png}
overlay0_full_screen = true
overlay0_descs = 0
# Game viewport inside the CRT tube (fractions of screen)
overlay0_viewport = "0.220,0.080,0.560,0.840"
overlay0_viewport_fill = true
EOF

# Absolute path for overlay0 when using our cfg in bezel dir — rewrite to relative png copy
if [[ -f "$TV_PNG" ]]; then
  cp -n "$TV_PNG" "${BEZEL_DIR}/crt-tv.png" 2>/dev/null || cp -f "$TV_PNG" "${BEZEL_DIR}/crt-tv.png"
  cat >"${BEZEL_DIR}/crt-tv.cfg" <<'EOF'
overlays = 1
overlay0_overlay = crt-tv.png
overlay0_full_screen = true
overlay0_descs = 0
overlay0_viewport = "0.220,0.080,0.560,0.840"
overlay0_viewport_fill = true
EOF
fi

OVERLAY_PATH="${BEZEL_DIR}/crt-tv.cfg"

echo "=== Patching global retroarch.cfg for CRT TV bezels ==="
set_ra overlay_directory "$OV"
set_ra input_overlay_enable "true"
set_ra input_overlay "$OVERLAY_PATH"
set_ra input_overlay_opacity "1.000000"
set_ra input_overlay_hide_in_menu "true"
set_ra input_overlay_hide_when_gamepad_connected "false"
set_ra input_overlay_behind_menu "false"
set_ra input_overlay_auto_scale "false"
set_ra input_overlay_enable_autopreferred "true"
# 4:3 CRT look; 22 often = "Core provided" — use 1 = 4:3 if available
# aspect_ratio_index: 0=4/3 config, 1=16/9, ... check docs; "22" was core provided
set_ra aspect_ratio_index "0"
set_ra video_scale_integer "false"
set_ra video_aspect_ratio_auto "false"
set_ra custom_viewport_width "0"
set_ra custom_viewport_height "0"
# menu still shows thumbs
set_ra menu_thumbnails "3"
set_ra menu_left_thumbnails "1"
set_ra network_on_demand_thumbnails "true"
set_ra thumbnails_directory "${RA}/thumbnails"
set_ra content_database_path "${RA}/database/rdb"

# Per-core configs so bezel always loads for our systems even if global toggled
write_core_overlay() {
  local dir="$1"
  local f="${CONFIG_DIR}/${dir}/${dir}.cfg"
  # Some cores use folder name = core name; write both patterns
  mkdir -p "$(dirname "$f")"
  # Also write generic options file used by many cores
  local opts="${CONFIG_DIR}/${dir}/${dir}.opt"
  cat >"$f" <<EOF
input_overlay_enable = "true"
input_overlay = "${OVERLAY_PATH}"
input_overlay_opacity = "1.000000"
input_overlay_hide_in_menu = "true"
aspect_ratio_index = "0"
video_scale_integer = "false"
EOF
  echo "wrote $f"
}

for core in \
  "Nestopia" \
  "Mesen" \
  "Snes9x" \
  "bsnes" \
  "Mupen64Plus-Next" \
  "ParaLLEl N64" \
  "Genesis Plus GX" \
  "PicoDrive"
do
  write_core_overlay "$core"
done

# Download optional higher-quality CRT TV frames from libre/common overlay packs
# (stock tv-integer is already good; try github raw for a classic set if network allows)
echo
echo "=== Optional: fetch extra CRT frames (best-effort) ==="
EXTRA_URLS=(
  # Libretro common borders already installed under overlays/borders
)
# Attempt Bezel Project-style system default (horizontal) — may 404; non-fatal
fetch_bezel() {
  local name="$1" url="$2"
  local dest="${BEZEL_DIR}/${name}"
  if [[ -f "$dest" ]]; then
    echo "have $dest"
    return 0
  fi
  if curl -fsSL --connect-timeout 15 --max-time 60 -o "${dest}.part" "$url"; then
    mv "${dest}.part" "$dest"
    echo "fetched $dest"
  else
    rm -f "${dest}.part"
    echo "skip $name (unavailable)"
  fi
}

# Classic TV bezel alternatives from libretro overlays repo raw (if present)
fetch_bezel "crt-tv-alt.png" \
  "https://raw.githubusercontent.com/libretro/common-overlays/master/borders/img/tv-integer.png" || true

echo
echo "=== Current overlay settings ==="
grep -E '^input_overlay|^aspect_ratio_index|^video_scale_integer|^menu_thumbnails|^content_database|^thumbnails_directory' "$CFG" | head -20
echo
echo "Bezel: $OVERLAY_PATH"
ls -la "$BEZEL_DIR"
echo
echo "Done. Fully quit RetroArch and relaunch: ~/bin/launch-retroarch.sh"
echo "In-game you should see a CRT TV frame around the game."
echo "Toggle: Quick Menu (F1) → On-Screen Overlay → Display Overlay"
echo "Disable globally: Settings → On-Screen Display → On-Screen Overlay → Display Overlay = OFF"
