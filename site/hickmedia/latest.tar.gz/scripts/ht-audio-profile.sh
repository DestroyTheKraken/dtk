#!/usr/bin/env bash
# Media Hub audio profiles: Movies | Music | Gaming
# All stay on the pro interface @ 48 kHz; only quantum / latency changes.
#
#   ht-audio-profile.sh movies   # stable, moderate latency (~21–43 ms)
#   ht-audio-profile.sh music    # lower latency for monitoring feel
#   ht-audio-profile.sh gaming   # largest quantum — fewest xruns under load
#   ht-audio-profile.sh status
set -euo pipefail

log() { echo "[ht-audio-profile] $*"; }

force_48k() {
  pw-metadata -n settings 0 clock.force-rate 48000 >/dev/null 2>&1 || true
}

set_quantum() {
  local q="$1"
  pw-metadata -n settings 0 clock.force-quantum "$q" >/dev/null 2>&1 || true
  log "force-rate=48000 force-quantum=$q"
}

prefer_interface_default() {
  # Prefer USB pro sink/source if present
  local sid src
  sid=$(wpctl status 2>/dev/null | sed -n '/Sinks:/,/Sources:/p' \
    | grep -iE 'usb|PreSonus|Focusrite|Behringer|Scarlet|Studio|Interface' \
    | grep -vE 'hdmi|HDMI' | head -1 | grep -oE '[0-9]+' | head -1 || true)
  if [[ -z "${sid:-}" ]]; then
    sid=$(wpctl status 2>/dev/null | sed -n '/Sinks:/,/Sources:/p' \
      | grep -iE 'usb-' | head -1 | grep -oE '[0-9]+' | head -1 || true)
  fi
  if [[ -n "${sid:-}" ]]; then
    wpctl set-default "$sid" 2>/dev/null && log "default sink id=$sid" || true
  else
    log "WARN: no USB/pro sink found — leave desktop default"
  fi
  src=$(wpctl status 2>/dev/null | sed -n '/Sources:/,/Filters/p' \
    | grep -iE 'usb|PreSonus|Focusrite|Behringer|Studio' \
    | head -1 | grep -oE '[0-9]+' | head -1 || true)
  if [[ -n "${src:-}" ]]; then
    wpctl set-default "$src" 2>/dev/null && log "default source id=$src" || true
  fi
}

status() {
  echo "=== Media Hub audio status ==="
  pactl info 2>/dev/null | grep -iE 'Default Sink|Default Source|Default Sample' || true
  echo "--- clock ---"
  pw-metadata -n settings 0 2>/dev/null | grep -i clock || true
  echo "--- sinks ---"
  wpctl status 2>/dev/null | sed -n '/Sinks:/,/Sources:/p' | head -20
  if lsusb 2>/dev/null | grep -qiE '194f:010c|PreSonus|Focusrite|Behringer|0d8c|Audio'; then
    lsusb | grep -iE '194f|PreSonus|Focusrite|Behringer|Audio|0d8c' || true
  fi
}

MODE="${1:-status}"
case "$MODE" in
  movies|movie|film|tv)
    # Film/TV: stable buffer, still snappy enough for UI
    force_48k
    set_quantum 1024
    prefer_interface_default
    log "profile=MOVIES (48 kHz / q=1024) → interface → speakers"
    ;;
  music|hi-fi|hifi)
    # Music: slightly lower latency for feel; still xrun-safe
    force_48k
    set_quantum 512
    prefer_interface_default
    log "profile=MUSIC (48 kHz / q=512) → interface → speakers"
    ;;
  gaming|game|retro)
    # Gaming/RetroArch: max stability under GPU+CPU load
    force_48k
    set_quantum 2048
    prefer_interface_default
    log "profile=GAMING (48 kHz / q=2048) → interface → speakers"
    ;;
  hub|normal|default)
    force_48k
    set_quantum 1024
    prefer_interface_default
    log "profile=HUB default (48 kHz / q=1024)"
    ;;
  status|st)
    status
    ;;
  *)
    echo "usage: $0 movies|music|gaming|hub|status" >&2
    exit 1
    ;;
esac
