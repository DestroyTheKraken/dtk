#!/usr/bin/env bash
# Configure RetroArch for TWO identical 8BitDo Pro 2 Wired controllers (X-Input).
# Product page: https://www.8bitdo.com/pro2-wired-controller/
#
# Mode: hold X while plugging in for X-Input (PC) mode — recommended on Linux.
# On Linux these often appear as "Microsoft Xbox Series S|X Controller" (045e:0b12).
# Run on hickmedia: bash ~/HickMedia/scripts/configure-8bitdo-dual.sh
set -euo pipefail

RA="$HOME/.config/retroarch"
CFG="$RA/retroarch.cfg"
AUTO_UDEV="$RA/autoconfig/udev"
mkdir -p "$AUTO_UDEV" "$RA/autoconfig"

# 045e:0b12 → decimal 1118:2834 (xpad Xbox Series ID — what Pro 2 uses in X-Input)
VID=1118
PID=2834

# Standard xpad / Xbox Series button map (same as Microsoft_X-Box_Series_XS_pad.cfg)
write_xbox_spoof_autoconfig() {
  local path="$1"
  local device_name="$2"
  local display_name="${3:-8BitDo Pro 2 Wired (X-Input)}"
  cat >"$path" <<EOF
# 8BitDo Pro 2 Wired in X-Input mode — appears as Xbox Series controller.
# https://www.8bitdo.com/pro2-wired-controller/
# Mode: hold X while plugging USB (X-Input / PC).
# Identical profile applies to BOTH controllers when two are connected.

input_driver = "udev"
input_device = "${device_name}"
input_device_display_name = "${display_name}"

input_vendor_id = "${VID}"
input_product_id = "${PID}"

input_b_btn = "0"
input_y_btn = "2"
input_select_btn = "6"
input_start_btn = "7"
input_up_btn = "h0up"
input_down_btn = "h0down"
input_left_btn = "h0left"
input_right_btn = "h0right"
input_a_btn = "1"
input_x_btn = "3"
input_l_btn = "4"
input_r_btn = "5"
input_l2_axis = "+2"
input_r2_axis = "+5"
input_l3_btn = "9"
input_r3_btn = "10"
input_l_x_plus_axis = "+0"
input_l_x_minus_axis = "-0"
input_l_y_plus_axis = "+1"
input_l_y_minus_axis = "-1"
input_r_x_plus_axis = "+3"
input_r_x_minus_axis = "-3"
input_r_y_plus_axis = "+4"
input_r_y_minus_axis = "-4"
input_menu_toggle_btn = "8"

# Hotkeys: Select = modifier; Start+Select exit (optional)
input_enable_hotkey_btn = "6"
input_exit_emulator_btn = "7"

input_b_btn_label = "A (south / bottom)"
input_a_btn_label = "B (east / right)"
input_y_btn_label = "X (west / left)"
input_x_btn_label = "Y (north / top)"
input_select_btn_label = "View / Select"
input_start_btn_label = "Menu / Start"
input_menu_toggle_btn_label = "Guide / Home"
input_l_btn_label = "LB"
input_r_btn_label = "RB"
input_l2_axis_label = "LT"
input_r2_axis_label = "RT"
input_l3_btn_label = "L3"
input_r3_btn_label = "R3"
input_up_btn_label = "D-Pad Up"
input_down_btn_label = "D-Pad Down"
input_left_btn_label = "D-Pad Left"
input_right_btn_label = "D-Pad Right"
EOF
  echo "wrote $path"
}

# Exact name from this machine's /proc/bus/input/devices (xpad):
write_xbox_spoof_autoconfig \
  "$AUTO_UDEV/Microsoft_Xbox_Series_S_X_Controller_8BitDo.cfg" \
  "Microsoft Xbox Series S|X Controller" \
  "8BitDo Pro 2 Wired (X-Input)"

# Stock libretro name variants
write_xbox_spoof_autoconfig \
  "$AUTO_UDEV/Microsoft_X-Box_Series_XS_pad.cfg" \
  "Microsoft X-Box Series X|S pad" \
  "Xbox Series X/S Controller"

# Older Pro 2 native ID 2dc8:3106 (if not spoofing)
VID_8BIT=11720
PID_8BIT=12550
cat >"$AUTO_UDEV/8BitDo_Pro_2_Wired_XInput.cfg" <<EOF
# 8BitDo Pro 2 Wired native VID:PID (2dc8:3106) when not spoofing Xbox ID
input_driver = "udev"
input_device = "8BitDo Ultimate Wireless / Pro 2 Wired Controller"
input_device_display_name = "8BitDo Pro 2 Wired"
input_vendor_id = "${VID_8BIT}"
input_product_id = "${PID_8BIT}"
input_up_btn = "h0up"
input_down_btn = "h0down"
input_left_btn = "h0left"
input_right_btn = "h0right"
input_a_btn = "1"
input_b_btn = "0"
input_x_btn = "3"
input_y_btn = "2"
input_select_btn = "6"
input_start_btn = "7"
input_menu_toggle_btn = "8"
input_l_btn = "4"
input_r_btn = "5"
input_l2_axis = "+2"
input_r2_axis = "+5"
input_l3_btn = "9"
input_r3_btn = "10"
input_l_x_plus_axis = "+0"
input_l_x_minus_axis = "-0"
input_l_y_plus_axis = "+1"
input_l_y_minus_axis = "-1"
input_r_x_plus_axis = "+3"
input_r_x_minus_axis = "-3"
input_r_y_plus_axis = "+4"
input_r_y_minus_axis = "-4"
input_enable_hotkey_btn = "6"
input_exit_emulator_btn = "7"
EOF
echo "wrote $AUTO_UDEV/8BitDo_Pro_2_Wired_XInput.cfg"
cp -f "$AUTO_UDEV/8BitDo_Pro_2_Wired_XInput.cfg" \
  "$AUTO_UDEV/8BitDo Ultimate Wireless - Pro 2 Wired Controller.cfg"

# Patch retroarch.cfg for dual-pad multiplayer
[[ -f "$CFG" ]] || { echo "missing $CFG — run configure-retroarch-frontend.sh first"; exit 1; }

set_ra() {
  local key="$1" val="$2"
  if grep -qE "^${key} *=" "$CFG"; then
    sed -i "s|^${key} *=.*|${key} = \"${val}\"|" "$CFG"
  else
    echo "${key} = \"${val}\"" >>"$CFG"
  fi
}

echo "=== Patching retroarch.cfg for 2 players ==="
set_ra input_driver "udev"
set_ra input_joypad_driver "udev"
set_ra input_autodetect_enable "true"
set_ra input_max_users "4"
set_ra input_player1_joypad_index "0"
set_ra input_player2_joypad_index "1"
set_ra input_player3_joypad_index "2"
set_ra input_player4_joypad_index "3"
set_ra input_device_p1 "0"
set_ra input_device_p2 "1"
set_ra input_device_p3 "2"
set_ra input_device_p4 "3"
set_ra input_player1_analog_dpad_mode "1"
set_ra input_player2_analog_dpad_mode "1"
set_ra all_users_control_menu "true"
set_ra menu_unified_controls "true"
set_ra menu_swap_ok_cancel_buttons "false"
set_ra input_axis_threshold "0.250000"
set_ra input_analog_deadzone "0.150000"
# Couch hotkeys (X-Input): hold Select(6)+Start(7)=close game; Select+Guide(8)=menu
# Combo 4 = Start+Select also toggles quick menu
set_ra input_enable_hotkey_btn "6"
set_ra input_close_content_btn "7"
set_ra input_exit_emulator_btn "nul"
set_ra input_exit_emulator "escape"
set_ra input_menu_toggle_btn "8"
set_ra input_menu_toggle "f1"
set_ra input_menu_toggle_gamepad_combo "4"
set_ra input_quit_gamepad_combo "0"
set_ra quit_on_close_content "0"
set_ra input_player1_select_btn "6"
set_ra input_player1_start_btn "7"
set_ra autoconfig_directory "$RA/autoconfig"
set_ra auto_remaps_enable "true"

grep -nE '^input_driver|^input_joypad|^input_player1_joypad|^input_player2_joypad|^input_device_p1|^input_device_p2|^input_max_users|^all_users' "$CFG" || true

echo
echo "=== Controllers currently seen by OS ==="
n_js=$(ls /dev/input/js* 2>/dev/null | wc -l)
echo "joystick nodes: $n_js"
ls -la /dev/input/js* 2>/dev/null || true
echo
grep -E 'Name=|Handlers=.*js' /proc/bus/input/devices | paste - - 2>/dev/null || true
echo
echo "USB pads (045e:0b12 / 2dc8:*):"
lsusb 2>/dev/null | grep -iE '045e:0b12|2dc8|8Bit|Xbox' || true
echo
# Detect half-dead USB (enumerated but no config) — common with two pads
for d in /sys/bus/usb/devices/*; do
  [ -f "$d/idVendor" ] || continue
  v=$(cat "$d/idVendor" 2>/dev/null)
  p=$(cat "$d/idProduct" 2>/dev/null)
  if [ "$v" = "045e" ] && [ "$p" = "0b12" ]; then
    conf=$(cat "$d/bConfigurationValue" 2>/dev/null || true)
    ser=$(cat "$d/serial" 2>/dev/null || true)
    if [ -z "$conf" ]; then
      echo "WARN: $d serial=$ser has NO USB config (kernel error -71). Unplug & replug this pad on another port."
    else
      echo "OK:   $d serial=$ser config=$conf"
    fi
  fi
done

echo
echo "=== Done ==="
if [[ "$n_js" -lt 2 ]]; then
  echo "NEED 2 pads as /dev/input/js0 and js1 (currently $n_js)."
  echo "1. Unplug BOTH controllers."
  echo "2. Hold X on Player 1 pad, plug into a rear motherboard USB port."
  echo "3. Hold X on Player 2 pad, plug into a DIFFERENT port (not a weak hub)."
  echo "4. Re-run: bash ~/HickMedia/scripts/configure-8bitdo-dual.sh"
  echo "5. Fully quit RetroArch, then: ~/bin/launch-retroarch.sh"
else
  echo "Both js0+js1 present. Fully quit RetroArch and relaunch:"
  echo "  ~/bin/launch-retroarch.sh"
  echo "Settings → Input → Port 1 Device Index = first pad, Port 2 = second."
fi
echo
echo "In 2-player games: Player 1 = Port 1, Player 2 = Port 2."
echo "If Port 2 is empty: Settings → Input → Port 2 Controls → Device Index."
