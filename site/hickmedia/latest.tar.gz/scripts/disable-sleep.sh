#!/usr/bin/env bash
# Prevent hickmedia from suspending (always-on media client).
# Run on hickmedia:
#   bash ~/HickMedia/scripts/disable-sleep.sh
#   # or with password:
#   ssh -t hickmedia 'bash ~/HickMedia/scripts/disable-sleep.sh'
set -euo pipefail

echo "=== disable-sleep on $(hostname) $(date -Is) ==="

run_root() {
  if [[ "$(id -u)" -eq 0 ]]; then
    "$@"
  elif sudo -n true 2>/dev/null; then
    sudo "$@"
  else
    echo "Need sudo for system power policy. Re-run with:"
    echo "  ssh -t hickmedia 'bash ~/HickMedia/scripts/disable-sleep.sh'"
    sudo "$@"
  fi
}

# --- 1) systemd: block suspend/hibernate entirely ---
echo "==> mask sleep targets"
for t in sleep.target suspend.target hibernate.target hybrid-sleep.target; do
  run_root systemctl mask "$t" || true
done

# --- 2) logind: ignore lid / idle / suspend keys ---
echo "==> logind drop-in"
run_root mkdir -p /etc/systemd/logind.conf.d
run_root tee /etc/systemd/logind.conf.d/00-hickmedia-no-sleep.conf >/dev/null <<'EOF'
[Login]
# HickMedia appliance — never suspend
HandleSuspendKey=ignore
HandleHibernateKey=ignore
HandleLidSwitch=ignore
HandleLidSwitchExternalPower=ignore
HandleLidSwitchDocked=ignore
IdleAction=ignore
IdleActionSec=0
EOF
run_root systemctl restart systemd-logind

# --- 3) Wi-Fi: disable powersave (helps Tailscale stay up) ---
echo "==> NetworkManager wifi powersave off"
if command -v nmcli >/dev/null; then
  # Global default for new connections
  run_root mkdir -p /etc/NetworkManager/conf.d
  run_root tee /etc/NetworkManager/conf.d/00-hickmedia-wifi-powersave.conf >/dev/null <<'EOF'
[connection]
wifi.powersave = 2
EOF
  # 2 = disable powersave (NM docs)
  CONN=$(nmcli -t -f NAME,DEVICE connection show --active 2>/dev/null | awk -F: '$2 ~ /^w/ {print $1; exit}')
  if [[ -n "${CONN:-}" ]]; then
    nmcli connection modify "$CONN" wifi.powersave 2 2>/dev/null || true
    nmcli connection up "$CONN" 2>/dev/null || true
    echo "wifi connection: $CONN powersave=2"
  fi
  run_root systemctl reload NetworkManager 2>/dev/null || true
fi

# --- 4) Plasma (Ubuntu Studio) powerdevil — AC: never sleep ---
echo "==> Plasma power profiles (user)"
# Plasma 5/6 power management config
for KW in kwriteconfig6 kwriteconfig5; do
  command -v "$KW" >/dev/null 2>&1 || continue
  # AC profile: no suspend
  "$KW" --file powermanagementprofilesrc --group AC --group SuspendSession --key idleTime 0 2>/dev/null || true
  "$KW" --file powermanagementprofilesrc --group AC --group SuspendSession --key suspendType 0 2>/dev/null || true
  "$KW" --file powermanagementprofilesrc --group AC --group DPMSControl --key idleTime 0 2>/dev/null || true
  "$KW" --file powermanagementprofilesrc --group AC --group DimDisplay --key idleTime 0 2>/dev/null || true
  "$KW" --file powermanagementprofilesrc --group AC --group HandleButtonEvents --key lidAction 0 2>/dev/null || true
  "$KW" --file powermanagementprofilesrc --group AC --group HandleButtonEvents --key powerButtonAction 0 2>/dev/null || true
  # Battery profile too (if ever on UPS)
  "$KW" --file powermanagementprofilesrc --group Battery --group SuspendSession --key idleTime 0 2>/dev/null || true
  "$KW" --file powermanagementprofilesrc --group Battery --group SuspendSession --key suspendType 0 2>/dev/null || true
  echo "wrote via $KW"
  break
done

# GNOME fallback (if present)
if command -v gsettings >/dev/null && gsettings list-schemas 2>/dev/null | grep -q org.gnome.settings-daemon.plugins.power; then
  gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-ac-type 'nothing' 2>/dev/null || true
  gsettings set org.gnome.settings-daemon.plugins.power sleep-inactive-battery-type 'nothing' 2>/dev/null || true
  gsettings set org.gnome.desktop.session idle-delay 0 2>/dev/null || true
  echo "gsettings power tweaks applied"
fi

# Screen blank only (optional) — leave DPMS off for TV appliance
if command -v xset >/dev/null && [[ -n "${DISPLAY:-}" ]]; then
  xset s off 2>/dev/null || true
  xset -dpms 2>/dev/null || true
fi

echo
echo "=== verify ==="
systemctl is-enabled sleep.target suspend.target hibernate.target hybrid-sleep.target 2>&1 || true
ls -la /etc/systemd/logind.conf.d/00-hickmedia-no-sleep.conf
echo "done — machine should no longer auto-suspend"
echo "Note: re-login to Plasma (or reboot) so powerdevil reloads fully."
