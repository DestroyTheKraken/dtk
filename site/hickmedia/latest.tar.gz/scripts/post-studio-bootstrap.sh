#!/usr/bin/env bash
# DEPRECATED — use: sudo bash installer/install.sh --profile full-hub
echo "DEPRECATED: scripts/post-studio-bootstrap.sh → installer/install.sh" >&2
echo "Running legacy script for compatibility..." >&2
ROOT="$(cd "$(dirname "$0")" && pwd)"
exec bash "$ROOT/legacy/post-studio-bootstrap.sh" "$@"
