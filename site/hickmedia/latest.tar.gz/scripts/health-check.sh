#!/usr/bin/env bash
# HickMedia health check — run on hickmedia: ~/bin/health-check.sh
set +e
ok=0
fail=0
warn=0
pass() { echo "OK   $1"; ok=$((ok + 1)); }
fail_() { echo "FAIL $1"; fail=$((fail + 1)); }
warn_() { echo "WARN $1"; warn=$((warn + 1)); }

echo "=== HickMedia health $(date -Is) host=$(hostname) ==="

systemctl --user is-active --quiet pipewire && pass "pipewire active" || fail_ "pipewire active"
systemctl --user is-active --quiet wireplumber && pass "wireplumber active" || fail_ "wireplumber active"
systemctl --user is-active --quiet ht-audio-route.service && pass "ht-audio-route active" || fail_ "ht-audio-route active"

if lsusb 2>/dev/null | grep -qiE '194f:010c|PreSonus'; then pass "1810c USB present"; else fail_ "1810c USB present"; fi
if pactl get-default-sink 2>/dev/null | grep -qiE '1810c|PreSonus'; then pass "1810c default sink"; else fail_ "1810c default sink"; fi

# Ardour must not be the 24/7 mixer (pgrep -f can false-positive; use full path match)
if pgrep -f '/usr/lib/ardour8/ardour-8' >/dev/null 2>&1; then
  fail_ "ardour not running (still running — stop it)"
else
  pass "ardour not running"
fi

n=$(pw-link -l 2>/dev/null | grep -c 'capture_AUX' || true)
if [[ "${n:-0}" -ge 6 ]]; then pass "hw mix links present ($n)"; else fail_ "hw mix links present ($n)"; fi

# Jellyfin: server may be remote (um690). Client mode = Desktop installed or server reachable.
if docker ps 2>/dev/null | grep -q jellyfin \
  || pgrep -f 'org.jellyfin.JellyfinServer' >/dev/null 2>&1 \
  || ss -lntp 2>/dev/null | grep -qE ':8096|:18096'; then
  pass "jellyfin server local"
elif flatpak list --user 2>/dev/null | grep -qi JellyfinDesktop \
  || curl -sS -o /dev/null -w '' --connect-timeout 2 http://100.120.232.39:18096/ 2>/dev/null; then
  pass "jellyfin client/server path OK (um690 :18096)"
else
  warn_ "jellyfin client/server not verified"
fi

if command -v retroarch >/dev/null 2>&1 \
  || flatpak list --user 2>/dev/null | grep -qi RetroArch; then
  pass "retroarch installed"
else
  warn_ "retroarch not installed"
fi

if loginctl show-user "$(id -un)" -p Linger 2>/dev/null | grep -q 'Linger=yes'; then
  pass "user linger enabled"
else
  warn_ "linger=no (sudo-setup enables this)"
fi

echo "--- default devices ---"
pactl get-default-sink 2>/dev/null
pactl get-default-source 2>/dev/null
echo "--- sample links ---"
pw-link -l 2>/dev/null | grep -iE 'capture_AUX|playback_FL|playback_FR' | head -24
echo "=== summary ok=$ok warn=$warn fail=$fail ==="
if [[ "$fail" -gt 0 ]]; then exit 1; fi
exit 0
