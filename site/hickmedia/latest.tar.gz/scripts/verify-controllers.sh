#!/usr/bin/env bash
# Quick dual-controller check for hickmedia RetroArch multiplayer.
set -euo pipefail

echo "=== USB controllers ==="
lsusb 2>/dev/null | grep -iE '045e:0b12|2dc8|8Bit|Xbox|Controller' || echo "(none matching)"

echo
echo "=== Joystick nodes (need js0 + js1) ==="
ls -la /dev/input/js* 2>/dev/null || echo "(no /dev/input/js*)"
n_js=$(ls /dev/input/js* 2>/dev/null | wc -l)

echo
echo "=== Input names ==="
awk '
  /^N: Name=/ { name=$0 }
  /js[0-9]/ {
    print name
    print
    print "---"
  }
' /proc/bus/input/devices

echo
echo "=== USB config health (045e:0b12) ==="
for d in /sys/bus/usb/devices/*; do
  [ -f "$d/idVendor" ] || continue
  v=$(cat "$d/idVendor" 2>/dev/null)
  p=$(cat "$d/idProduct" 2>/dev/null)
  if [ "$v" = "045e" ] && [ "$p" = "0b12" ]; then
    conf=$(cat "$d/bConfigurationValue" 2>/dev/null || true)
    ser=$(cat "$d/serial" 2>/dev/null || true)
    if [ -z "${conf:-}" ]; then
      echo "BAD  $d serial=$ser  (no config — unplug/replug)"
    else
      echo "OK   $d serial=$ser  config=$conf"
    fi
  fi
done

echo
if [[ "$n_js" -ge 2 ]]; then
  echo "READY: $n_js pads. Quit RetroArch fully, then: ~/bin/launch-retroarch.sh"
  exit 0
else
  echo "NOT READY: only $n_js joystick node(s). Need 2."
  echo "Unplug both → hold X while plugging P1 → hold X while plugging P2 on another port."
  exit 1
fi
