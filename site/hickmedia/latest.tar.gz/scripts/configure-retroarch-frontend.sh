#!/usr/bin/env bash
# Configure RetroArch frontend on hickmedia for NES + Genesis MVP
# (playlists, cores, ozone theme, 8BitDo-friendly input, thumbnails from Batocera art)
set -euo pipefail

HOME_DIR="${HOME:-/home/kraken}"
RA_DIR="$HOME_DIR/.config/retroarch"
CFG="$RA_DIR/retroarch.cfg"
CORE_DIR="$RA_DIR/cores"
PLAY_DIR="$RA_DIR/playlists"
THUMB_DIR="$RA_DIR/thumbnails"
ROMS="$HOME_DIR/ROMs"
ASSETS="/usr/share/libretro/assets"

mkdir -p "$CORE_DIR" "$PLAY_DIR" "$THUMB_DIR" "$RA_DIR/autoconfig" "$RA_DIR/config" \
  "$RA_DIR/system" "$RA_DIR/saves" "$RA_DIR/states" "$RA_DIR/screenshots"

echo "=== Writing default retroarch.cfg ==="
# Full practical defaults — Wayland + udev joystick + Ozone
cat >"$CFG" <<EOF
# HickMedia RetroArch defaults ($(date -Is))
# Theme: Ozone (clean). To use a custom theme, see docs/RETROARCH-FRONTEND.md

### Paths
libretro_directory = "$CORE_DIR"
libretro_info_path = "/usr/share/libretro/info"
rgui_browser_directory = "$ROMS"
content_directory = "$ROMS"
playlist_directory = "$PLAY_DIR"
thumbnails_directory = "$THUMB_DIR"
assets_directory = "$ASSETS"
system_directory = "$RA_DIR/system"
savefile_directory = "$RA_DIR/saves"
savestate_directory = "$RA_DIR/states"
screenshot_directory = "$RA_DIR/screenshots"
autoconfig_directory = "$RA_DIR/autoconfig"
menu_wallpaper = ""

### Menu / Theme (Ozone = modern basic UI)
menu_driver = "ozone"
menu_linear_filter = "true"
menu_horizontal_animation = "true"
menu_show_core_updater = "true"
menu_show_online_updater = "true"
menu_show_configurations = "true"
menu_show_load_core = "true"
menu_show_load_content = "true"
menu_show_information = "true"
menu_show_quit_retroarch = "true"
menu_show_restart_retroarch = "true"
menu_show_reboot = "false"
menu_show_shutdown = "false"
ozone_menu_color_theme = "1"
ozone_collapse_sidebar = "false"
ozone_thumbnail_scale_factor = "1.000000"
ozone_scroll_content_metadata = "true"
rgui_show_start_screen = "false"
menu_screensaver_timeout = "0"
timedate_enable = "true"
menu_ticker_type = "1"

### Playlist display
playlist_entry_rename = "false"
playlist_entry_remove_enable = "0"
playlist_show_sublabels = "true"
playlist_show_inline_core_name = "0"
playlist_fuzzy_archive_match = "true"
playlist_portable_paths = "false"
quick_menu_show_add_to_favorites = "true"
content_show_playlists = "true"
content_show_favorites = "true"
content_show_images = "false"
content_show_music = "false"
content_show_video = "false"
content_show_netplay = "false"
content_show_settings = "true"
content_show_history = "true"
content_show_add = "true"
content_show_explore = "true"

### Thumbnails (boxart + screenshot)
menu_thumbnails = "3"
menu_left_thumbnails = "1"
menu_thumbnail_upscale_threshold = "0"
menu_rgui_thumbnail_downscaler = "0"
xmb_vertical_thumbnails = "false"

### Video (fullscreen living room)
video_driver = "glcore"
video_fullscreen = "true"
video_windowed_fullscreen = "true"
video_vsync = "true"
video_smooth = "false"
video_scale_integer = "false"
video_font_enable = "true"
video_font_size = "32.000000"
video_message_pos_x = "0.050000"
video_message_pos_y = "0.050000"
suspend_screensaver_enable = "true"

### Audio → system default (PipeWire/Pulse → 1810c)
audio_driver = "pulse"
audio_enable = "true"
audio_sync = "true"
audio_latency = "64"

### Input — CRITICAL for Wayland + 8BitDo
# Do NOT use input_driver = "x" (breaks menu + pads under Wayland)
input_driver = "udev"
input_joypad_driver = "udev"
input_autodetect_enable = "true"
input_max_users = "4"
input_player1_joypad_index = "0"
input_player1_analog_dpad_mode = "1"
all_users_control_menu = "true"
menu_swap_ok_cancel_buttons = "false"
menu_unified_controls = "true"
input_menu_toggle_gamepad_combo = "2"
input_quit_gamepad_combo = "0"
input_enable_hotkey_btn = "nul"
auto_remaps_enable = "true"
input_axis_threshold = "0.250000"
input_analog_deadzone = "0.150000"
input_analog_sensitivity = "1.000000"
input_rumble_gain = "100"
vibrate_on_keypress = "false"
# Keyboard still works in menu
input_keyboard_layout = ""

### Hotkeys (keyboard fallback)
input_exit_emulator = "escape"
input_menu_toggle = "f1"
input_toggle_fast_forward = "space"
input_load_state = "f4"
input_save_state = "f2"
input_screenshot = "f8"
input_pause_toggle = "p"

### Core / content
core_info_cache_enable = "false"
load_dummy_on_core_shutdown = "true"
check_firmware_before_loading = "false"
auto_overrides_enable = "true"
auto_shaders_enable = "true"
sort_savefiles_enable = "true"
sort_savestates_enable = "true"
savestate_auto_index = "false"
savestate_auto_save = "false"
savestate_auto_load = "false"
pause_nonactive = "true"
fastforward_ratio = "0.000000"
rewind_enable = "false"

### Network updater (optional later)
core_updater_buildbot_url = "http://buildbot.libretro.com/nightly/linux/x86_64/latest/"
core_updater_buildbot_assets_url = "http://buildbot.libretro.com/assets/"
EOF

# 8BitDo Pro 2 autoconfig (Wired / X-Input style)
# Button indices vary; this is a solid baseline for udev SDL mapping
cat >"$RA_DIR/autoconfig/8BitDo_Pro_2_Wired_Controller.cfg" <<'EOF'
input_driver = "udev"
input_device = "8BitDo Ultimate Wireless / Pro 2 Wired Controller"
input_vendor_id = "11720"
input_product_id = "24835"
input_b_btn = "0"
input_y_btn = "3"
input_select_btn = "6"
input_start_btn = "7"
input_up_btn = "h0up"
input_down_btn = "h0down"
input_left_btn = "h0left"
input_right_btn = "h0right"
input_a_btn = "1"
input_x_btn = "2"
input_l_btn = "4"
input_r_btn = "5"
input_l2_axis = "+2"
input_r2_axis = "+5"
input_l3_btn = "9"
input_r3_btn = "10"
input_l_x_plus_axis = "+0"
input_l_x_minus_axis = "-0"
input_l_y_plus_axis = "+1"
input_l_y_minus_axis = "-1"
input_r_x_plus_axis = "+3"
input_r_x_minus_axis = "-3"
input_r_y_plus_axis = "+4"
input_r_y_minus_axis = "-4"
input_menu_toggle_btn = "8"
input_enable_hotkey_btn = "6"
input_exit_emulator_btn = "7"
EOF

# Also common alternate name
cp "$RA_DIR/autoconfig/8BitDo_Pro_2_Wired_Controller.cfg" \
  "$RA_DIR/autoconfig/8BitDo Ultimate Wireless - Pro 2 Wired Controller.cfg" 2>/dev/null || true

echo "=== Import NES + Genesis thumbnails from Batocera art ==="
python3 - <<'PY'
import json, os, shutil
from pathlib import Path

home = Path.home()
roms = home / "ROMs"
thumb_root = home / ".config/retroarch/thumbnails"
play_dir = home / ".config/retroarch/playlists"

# playlist file name -> (rom_subdir, playlist display name for thumbs)
systems = {
    "Nintendo - Nintendo Entertainment System.lpl": ("nes", "Nintendo - Nintendo Entertainment System"),
    "Sega - Mega Drive - Genesis.lpl": ("megadrive", "Sega - Mega Drive - Genesis"),
}

def find_art(sysdir: Path, label: str):
    """Return (boxart, snap) paths if found."""
    box = snap = None
    # Batocera images: Label-image.png, Label-thumb.png
    images = sysdir / "images"
    media_covers = sysdir / "media" / "covers"
    media_snaps = sysdir / "media" / "screenshots"
    candidates_box = [
        images / f"{label}-image.png",
        images / f"{label}-thumb.png",
        media_covers / f"{label}.png",
        media_covers / f"{label}.jpg",
        images / f"{label}-boxback.png",
    ]
    candidates_snap = [
        media_snaps / f"{label}.png",
        media_snaps / f"{label}.jpg",
        images / f"{label}-image.png",
        images / f"{label}-thumb.png",
    ]
    for p in candidates_box:
        if p.is_file():
            box = p
            break
    for p in candidates_snap:
        if p.is_file():
            snap = p
            break
    # fuzzy: any file starting with label
    if box is None and images.is_dir():
        for p in images.glob(f"{label}*image*"):
            box = p
            break
        if box is None:
            for p in images.glob(f"{label}*thumb*"):
                box = p
                break
    if snap is None and media_snaps.is_dir():
        for p in media_snaps.glob(f"{label}*"):
            if p.suffix.lower() in {".png", ".jpg", ".jpeg"}:
                snap = p
                break
    return box, snap

for lpl_name, (subdir, thumb_name) in systems.items():
    lpl = play_dir / lpl_name
    if not lpl.is_file():
        print(f"missing playlist {lpl}")
        continue
    data = json.loads(lpl.read_text())
    items = data.get("items") or []
    box_dir = thumb_root / thumb_name / "Named_Boxarts"
    snap_dir = thumb_root / thumb_name / "Named_Snaps"
    title_dir = thumb_root / thumb_name / "Named_Titles"
    for d in (box_dir, snap_dir, title_dir):
        d.mkdir(parents=True, exist_ok=True)
    sysdir = roms / subdir
    linked = 0
    for it in items:
        label = it.get("label") or Path(it.get("path", "")).stem
        # RetroArch thumbnail filename = label + .png
        box, snap = find_art(sysdir, label)
        dest_box = box_dir / f"{label}.png"
        dest_snap = snap_dir / f"{label}.png"
        dest_title = title_dir / f"{label}.png"
        if box and not dest_box.exists():
            try:
                if box.suffix.lower() in {".png"}:
                    os.symlink(box, dest_box)
                else:
                    shutil.copy2(box, dest_box.with_suffix(box.suffix))
                    # also png name expected — copy as-is with png suffix via hard copy name
                    shutil.copy2(box, dest_box)
                linked += 1
            except Exception as e:
                try:
                    shutil.copy2(box, dest_box)
                    linked += 1
                except Exception as e2:
                    print("box fail", label, e2)
        if snap and not dest_snap.exists():
            try:
                shutil.copy2(snap, dest_snap) if snap.suffix.lower() != ".png" else os.symlink(snap, dest_snap)
            except Exception:
                try:
                    shutil.copy2(snap, dest_snap)
                except Exception:
                    pass
        # titles: use marquee/wheel if present
        marquee = sysdir / "images" / f"{label}-marquee.png"
        wheel = sysdir / "media" / "wheels" / f"{label}.png"
        src_title = marquee if marquee.is_file() else (wheel if wheel.is_file() else box)
        if src_title and not dest_title.exists():
            try:
                if src_title.suffix.lower() == ".png":
                    os.symlink(src_title, dest_title)
                else:
                    shutil.copy2(src_title, dest_title)
            except Exception:
                try:
                    shutil.copy2(src_title, dest_title)
                except Exception:
                    pass
    print(f"{thumb_name}: boxarts linked/copied ~{linked}/{len(items)}")
    print(f"  boxarts dir count: {len(list(box_dir.glob('*')))}")
    print(f"  snaps dir count: {len(list(snap_dir.glob('*')))}")

print("thumbnail import done")
PY

# Rebuild playlists for NES + Genesis (clean) + keep SNES/N64
if [[ -x "$HOME_DIR/HickMedia/scripts/build-retroarch-playlists.sh" ]]; then
  bash "$HOME_DIR/HickMedia/scripts/build-retroarch-playlists.sh"
elif [[ -x "$HOME_DIR/HickMedia/scripts/build-retroarch-playlists.sh" ]]; then
  bash "$HOME_DIR/HickMedia/scripts/build-retroarch-playlists.sh"
fi

# Favorites-style menu: ensure only useful playlists not empty
echo "=== Playlists ==="
ls -la "$PLAY_DIR"/*.lpl 2>/dev/null || true

# Desktop entry that forces ozone + config
mkdir -p "$HOME_DIR/.local/share/applications" "$HOME_DIR/bin"
cat >"$HOME_DIR/bin/launch-retroarch.sh" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export DBUS_SESSION_BUS_ADDRESS="${DBUS_SESSION_BUS_ADDRESS:-unix:path=${XDG_RUNTIME_DIR}/bus}"
if [[ -z "${WAYLAND_DISPLAY:-}" ]]; then
  [[ -S ${XDG_RUNTIME_DIR}/wayland-0 ]] && export WAYLAND_DISPLAY=wayland-0
  [[ -S ${XDG_RUNTIME_DIR}/wayland-1 ]] && export WAYLAND_DISPLAY=wayland-1
fi
# Prefer udev for pads
export SDL_JOYSTICK_HIDAPI=1
exec retroarch -c "$HOME/.config/retroarch/retroarch.cfg" --menu "$@"
EOF
chmod +x "$HOME_DIR/bin/launch-retroarch.sh"

cat >"$HOME_DIR/.local/share/applications/hickmedia-retroarch.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=Play (RetroArch)
Comment=NES / Genesis / SNES / N64 playlists
Exec=$HOME_DIR/bin/launch-retroarch.sh
Icon=retroarch
Terminal=false
Categories=Game;
EOF

echo
echo "=== DONE ==="
echo "Config: $CFG"
echo "Launch: ~/bin/launch-retroarch.sh  OR  menu → Play (RetroArch)"
echo "Custom theme: put assets under $ASSETS or change assets_directory / menu_driver in cfg"
echo "  XMB themes live under assets/xmb/<theme-name>/"
echo "  Or set menu_driver = \"xmb\" and xmb_theme / xmb_font in retroarch.cfg"
echo "Controller: 8BitDo autoconfig installed; use D-pad/left stick to navigate, A/B to select/back"
echo "  If still dead: Settings → Input → Retropad Binds → Port 1 Controls → Bind All"
