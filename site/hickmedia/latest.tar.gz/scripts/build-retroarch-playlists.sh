#!/usr/bin/env bash
# Build RetroArch playlists for NES / SNES / Megadrive / N64 under ~/ROMs
# Run on hickmedia after ROMs are synced.
set -euo pipefail

ROMS="${ROMS:-$HOME/ROMs}"
PLAY="${PLAY:-$HOME/.config/retroarch/playlists}"
CORE_DIR="${CORE_DIR:-$HOME/.config/retroarch/cores}"
mkdir -p "$PLAY"

# system_dir|playlist_name|default_core_so|extensions (comma)
declare -a SYSTEMS=(
  "nes|Nintendo - Nintendo Entertainment System|nestopia_libretro.so|zip,nes,unf,unif,7z"
  "snes|Nintendo - Super Nintendo Entertainment System|snes9x_libretro.so|zip,sfc,smc,fig,swc,7z"
  "megadrive|Sega - Mega Drive - Genesis|genesis_plus_gx_libretro.so|zip,md,gen,bin,smd,7z"
  "n64|Nintendo - Nintendo 64|mupen64plus_next_libretro.so|zip,n64,z64,v64,7z"
)

build_one() {
  local dir="$1" name="$2" core="$3" exts="$4"
  local path="$ROMS/$dir"
  local out="$PLAY/${name}.lpl"
  local core_path="$CORE_DIR/$core"
  [[ -d "$path" ]] || { echo "skip missing $path"; return; }
  [[ -f "$core_path" ]] || { echo "WARN no core $core_path"; }

  python3 - "$path" "$out" "$name" "$core_path" "$core" "$exts" <<'PY'
import json, os, sys
from pathlib import Path

rom_dir = Path(sys.argv[1])
out = Path(sys.argv[2])
playlist_name = sys.argv[3]
core_path = sys.argv[4]
core_name = sys.argv[5]
exts = {e.lower().lstrip(".") for e in sys.argv[6].split(",")}

# skip art/media subdirs for game files
skip_dirs = {"images", "media", "manuals", "videos", "marquees", "screenshots", "covers", "boxart", "titles", "snaps"}

items = []
for root, dirs, files in os.walk(rom_dir):
    dirs[:] = [d for d in dirs if d.lower() not in skip_dirs and not d.startswith(".")]
    for f in files:
        p = Path(root) / f
        suf = p.suffix.lower().lstrip(".")
        if suf not in exts:
            continue
        # skip obvious non-roms
        if f.startswith("."):
            continue
        label = p.stem
        # strip common junk suffixes
        for junk in (" (USA)", " (Europe)", " (Japan)", " (World)"):
            pass
        items.append({
            "path": str(p.resolve()),
            "label": label,
            "core_path": core_path if Path(core_path).is_file() else "DETECT",
            "core_name": core_name.replace("_libretro.so", "") if Path(core_path).is_file() else "DETECT",
            "crc32": "DETECT",
            "db_name": f"{playlist_name}.lpl",
        })

items.sort(key=lambda x: x["label"].lower())
doc = {
    "version": "1.5",
    "default_core_path": core_path if Path(core_path).is_file() else "",
    "default_core_name": core_name.replace(".so", "") if Path(core_path).is_file() else "",
    "label_display_mode": 0,
    "right_thumbnail_mode": 0,
    "left_thumbnail_mode": 0,
    "sort_mode": 0,
    "items": items,
}
out.write_text(json.dumps(doc, indent=2) + "\n")
print(f"Wrote {out} with {len(items)} games")
PY
}

for spec in "${SYSTEMS[@]}"; do
  IFS='|' read -r dir name core exts <<<"$spec"
  build_one "$dir" "$name" "$core" "$exts"
done

echo "=== playlists ==="
ls -la "$PLAY"
echo "Done. Open RetroArch → Playlists"
