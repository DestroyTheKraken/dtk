#!/usr/bin/env bash
# Raise PipeWire quantum for gaming sessions (more stable, slightly more latency)
set -euo pipefail
MODE="${1:-game}" # game | normal
case "$MODE" in
  game)
    pw-metadata -n settings 0 clock.force-quantum 2048 2>/dev/null || true
    pw-metadata -n settings 0 clock.force-rate 48000 2>/dev/null || true
    echo "quantum forced 2048 @ 48k (gaming)"
    ;;
  normal|hub)
    pw-metadata -n settings 0 clock.force-quantum 0 2>/dev/null || true
    pw-metadata -n settings 0 clock.force-rate 0 2>/dev/null || true
    echo "quantum force cleared (use defaults)"
    ;;
  *)
    echo "usage: $0 game|normal" >&2
    exit 1
    ;;
esac
