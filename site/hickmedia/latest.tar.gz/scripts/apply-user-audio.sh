#!/usr/bin/env bash
# Apply headless audio hub (no sudo). Run on hickmedia as kraken.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
HOME_DIR="${HOME:-/home/kraken}"

echo "==> install configs from $ROOT"
mkdir -p \
  "$HOME_DIR/.config/pipewire/pipewire.conf.d" \
  "$HOME_DIR/.config/wireplumber/wireplumber.conf.d" \
  "$HOME_DIR/.config/systemd/user" \
  "$HOME_DIR/.config/autostart" \
  "$HOME_DIR/bin" \
  "$HOME_DIR/HickMedia"

install -m 644 "$ROOT/audio/pipewire.conf.d/10-ht-clock.conf" \
  "$HOME_DIR/.config/pipewire/pipewire.conf.d/10-ht-clock.conf"
# WirePlumber 0.4: main.lua.d (optional; routing script sets defaults)
if [[ -f "$ROOT/audio/wireplumber/main.lua.d/51-1810c-default.lua" ]]; then
  mkdir -p "$HOME_DIR/.config/wireplumber/main.lua.d"
  install -m 644 "$ROOT/audio/wireplumber/main.lua.d/51-1810c-default.lua" \
    "$HOME_DIR/.config/wireplumber/main.lua.d/51-1810c-default.lua" || true
fi

install -m 755 "$ROOT/scripts/ht-audio-route.sh" "$HOME_DIR/bin/ht-audio-route.sh"
install -m 755 "$ROOT/scripts/ht-gaming-quantum.sh" "$HOME_DIR/bin/ht-gaming-quantum.sh"
install -m 755 "$ROOT/scripts/health-check.sh" "$HOME_DIR/bin/health-check.sh"
install -m 644 "$ROOT/scripts/ht-audio-route.service" "$HOME_DIR/.config/systemd/user/ht-audio-route.service"

# Disable Ardour autostart (keep desktop file disabled)
if [[ -f "$HOME_DIR/.config/autostart/home-theater-mixer.desktop" ]]; then
  mkdir -p "$HOME_DIR/.config/autostart/disabled"
  mv -f "$HOME_DIR/.config/autostart/home-theater-mixer.desktop" \
    "$HOME_DIR/.config/autostart/disabled/home-theater-mixer.desktop.bak"
  echo "disabled Ardour autostart (moved to autostart/disabled/)"
fi
# Explicit Hidden autostart guard
cat >"$HOME_DIR/.config/autostart/home-theater-mixer.desktop" <<'EOF'
[Desktop Entry]
Type=Application
Name=Home Theater Mixer (DISABLED)
Exec=/bin/true
Hidden=true
X-GNOME-Autostart-enabled=false
EOF

# Stop running Ardour if present (headless path takes over)
if pgrep -f '/usr/lib/ardour8/ardour' >/dev/null 2>&1; then
  echo "stopping running Ardour..."
  pkill -f '/usr/lib/ardour8/ardour' || true
  sleep 2
fi

systemctl --user daemon-reload
systemctl --user enable ht-audio-route.service
# Restart PW stack to pick up clock conf
systemctl --user restart pipewire pipewire-pulse wireplumber filter-chain.service 2>/dev/null || \
  systemctl --user restart pipewire pipewire-pulse wireplumber
sleep 3
systemctl --user start ht-audio-route.service
systemctl --user status ht-audio-route.service --no-pager || true

echo "==> defaults"
wpctl status 2>/dev/null | head -40 || true
echo "==> run health"
"$HOME_DIR/bin/health-check.sh" || true
echo "==> user audio apply done"
echo "Note: loginctl enable-linger needs sudo (bootstrap-privileged.sh)"
