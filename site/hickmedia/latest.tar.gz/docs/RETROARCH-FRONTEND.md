# RetroArch frontend (hickmedia)

## Status (NES + SNES + Genesis + N64)

| Item | Path / notes |
|------|----------------|
| Config | `~/.config/retroarch/retroarch.cfg` |
| ROMs | `~/ROMs/{nes,snes,n64,megadrive}` |
| Playlists | `~/.config/retroarch/playlists/*.lpl` |
| Cores | `~/.config/retroarch/cores/*.so` |
| Thumbnails | `~/.config/retroarch/thumbnails/<Playlist Name>/{Named_Boxarts,Named_Titles,Named_Snaps}/` |
| Metadata (RDB) | `~/.config/retroarch/database/rdb/*.rdb` (libretro-database) |
| CRT TV bezel | `~/.config/retroarch/overlays/hickmedia-tv/crt-tv.cfg` |
| Assets / themes | `/usr/share/libretro/assets/` (system) |
| Launch | `~/bin/launch-retroarch.sh` or menu **Play (RetroArch)** |

## Artwork + metadata

Sources (free, official Libretro):

- **Art:** [thumbnails.libretro.com](https://thumbnails.libretro.com) — boxarts, title screens, in-game snaps
- **Metadata:** [libretro-database](https://github.com/libretro/libretro-database) RDB files

Refresh / re-scrape all playlist games:

```bash
# Full scrape (boxarts + titles + snaps + RDB) — ~10–20 min
bash ~/HickMedia/scripts/scrape-and-decorate.sh

# Report only
python3 ~/HickMedia/scripts/scrape-libretro-media.py --report-only
```

Coverage after last scrape (approx):

| System | Boxarts | Titles | Snaps |
|--------|---------|--------|-------|
| NES | ~98% | ~99% | ~99% |
| SNES | ~96% | ~97% | ~97% |
| N64 | ~86% | ~86% | ~86% |
| Genesis | ~72% | ~75% | ~76% |

Lower Genesis % is mostly rare / unlicensed / Taiwan dumps not in the Libretro art set.

In Ozone: right thumbnail = boxart, left can show title/snap (`menu_thumbnails` / `menu_left_thumbnails`).

## Retro TV bezels (in-game)

Enabled by default. Game plays inside a CRT TV frame.

```bash
bash ~/HickMedia/scripts/configure-retro-tv-bezels.sh
```

| Setting | Value |
|---------|--------|
| Overlay | `~/.config/retroarch/overlays/hickmedia-tv/crt-tv.cfg` |
| Opacity | 1.0 |
| Aspect | 4:3 (`aspect_ratio_index = 0`) |
| Hide in menu | yes |

- **Toggle in-game:** F1 → On-Screen Overlay → Display Overlay  
- **Global off:** Settings → On-Screen Display → On-Screen Overlay → Display Overlay = OFF  
- Per-core copies under `~/.config/retroarch/config/{Nestopia,Snes9x,Genesis Plus GX,Mupen64Plus-Next,…}/`

## How to open games

1. Start **Play (RetroArch)** (not random RetroArch if it points at wrong cfg).
2. Main menu → **Playlists**.
3. **Nintendo - Nintendo Entertainment System** or **Sega - Mega Drive - Genesis**.
4. Pick a game (box art on the side with Ozone).
5. **A** = OK · **B** = Back · **F1** = quick menu in-game · **Esc** = exit.

### Controllers (two × 8BitDo Pro 2 Wired)

Product: [8BitDo Pro 2 Wired](https://www.8bitdo.com/pro2-wired-controller/)

| Setting | Value |
|---------|--------|
| Mode | **X-Input** — hold **X** while plugging USB |
| Linux name | `8BitDo Ultimate Wireless / Pro 2 Wired Controller` |
| VID:PID | `2dc8:3106` |
| Autoconfig | `~/.config/retroarch/autoconfig/udev/8BitDo_Pro_2_Wired_XInput.cfg` |
| Drivers | `input_driver` / `input_joypad_driver` = **udev** |
| Port 1 | joypad index **0** (first pad plugged) |
| Port 2 | joypad index **1** (second pad) |
| Script | `bash ~/HickMedia/scripts/configure-8bitdo-dual.sh` |

**Local multiplayer:** both pads plugged → Port 1 = P1, Port 2 = P2 in any 2-player game.

If a pad does nothing in the menu:

1. Fully quit RetroArch, unplug both, plug **P1** then **P2**, relaunch `~/bin/launch-retroarch.sh`
2. **Settings → Input → Port 1 Controls → Device Index** = first pad  
   **Port 2 Controls → Device Index** = second pad  
3. Or **Bind All** once per port if autoconfig missed a mode switch

## Custom themes

### Ozone (current default)

Built-in. Color: `ozone_menu_color_theme` in `retroarch.cfg` (0–N).

### XMB themes (common community packs)

1. Download an XMB theme pack (folder of icons/fonts).
2. Copy into user assets (recommended — no root):

```bash
mkdir -p ~/.config/retroarch/assets/xmb
# extract theme so you have:
# ~/.config/retroarch/assets/xmb/MyTheme/...
```

3. Edit `~/.config/retroarch/retroarch.cfg`:

```text
assets_directory = "/home/kraken/.config/retroarch/assets"
menu_driver = "xmb"
xmb_menu_color_theme = "0"
# optional: xmb_font = "..."
```

4. Restart RetroArch.

### Ozone still, custom wallpaper

```text
menu_wallpaper = "/home/kraken/Pictures/my-bg.png"
```

## Re-run setup after changes

```bash
bash ~/HickMedia/scripts/configure-retroarch-frontend.sh
bash ~/HickMedia/scripts/build-retroarch-playlists.sh
bash ~/HickMedia/scripts/configure-retro-tv-bezels.sh
bash ~/HickMedia/scripts/scrape-and-decorate.sh   # art + metadata + bezel
```

## Movies path (reminder)

| Content | Machine | Path |
|---------|---------|------|
| Movies | **um690** | `/mnt/systems_admin/kraken/media/movies/` |
| TV | **um690** | `/mnt/systems_admin/kraken/media/tv/` |
| Watch URL | hickmedia browser | https://hickmedia.taile52ad9.ts.net/mov |
