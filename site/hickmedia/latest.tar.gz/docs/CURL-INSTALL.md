# How `curl | sh` install works (and USB)

## Why this pattern

Same idea as **Grok Build** and many modern tools:

| Piece | Role |
|-------|------|
| **Tiny bootstrap** (`hickmedia.sh`) | Always the same URL; easy to remember |
| **Versioned payload** (`latest.tar.gz`) | Full installer + configs; can change every release |
| **One command** | Install **and** update by re-running the same line |

You do **not** put the whole product in the curl script (hard to maintain, huge).  
The bootstrap only knows *where* to get the payload and *how* to launch `installer/install.sh`.

## Online install

```bash
# Default: full-hub (client + Jellyfin + pro audio + appliance)
curl -fsSL https://www.destroythekraken.com/hickmedia.sh | sudo sh

# Choose profile
curl -fsSL https://www.destroythekraken.com/hickmedia.sh | sudo sh -s -- --profile media-server
curl -fsSL https://www.destroythekraken.com/hickmedia.sh | sudo sh -s -- --profile media-client --yes
```

### What happens step-by-step

1. **`curl -fsSL URL`**  
   - `-f` fail on HTTP errors  
   - `-sS` quiet but show errors  
   - `-L` follow redirects  
   Downloads `hickmedia.sh` **to stdout** (not saved as a file).

2. **`| sudo sh`**  
   Shell runs that script **from stdin** as root.

3. **Bootstrap script** then:  
   - Downloads `https://www.destroythekraken.com/hickmedia/latest.tar.gz`  
   - Extracts under `/opt/mediahub/src`  
   - Runs `bash /opt/mediahub/src/installer/install.sh --profile …`  
   - Installs `mediahub-update` for later upgrades  

4. **Installer** (product): packages, **pro audio essential**, Firefox/Brave Search, Jellyfin/RetroArch per profile.

### Passing arguments through the pipe

```bash
# IMPORTANT: use  sh -s --  so flags go to the script, not to sh
curl -fsSL …/hickmedia.sh | sudo sh -s -- --profile full-hub --yes
```

### Update

```bash
# Same command as install — fetches latest tarball and re-applies
curl -fsSL https://www.destroythekraken.com/hickmedia.sh | sudo sh

# Or after first install:
sudo mediahub-update
```

## USB / offline install

```bash
# On your build machine:
bash installer/pack-release.sh --out /run/media/$USER/VENTOY/hickmedia

# On customer PC (USB mounted):
sudo sh /media/$USER/VENTOY/hickmedia/hickmedia.sh --profile full-hub --yes
```

USB layout (from `pack-release.sh`):

```
hickmedia/
  hickmedia.sh           # bootstrap (detects local payload/)
  README-USB.txt
  payload/               # full HickMedia product tree
  hickmedia-latest.tar.gz
  SHA256SUMS
```

Bootstrap order of payload discovery:

1. `--local /path/to/HickMedia`  
2. Directory next to `hickmedia.sh` (`payload/` or tree with `installer/`)  
3. Download `HM_RELEASE_URL` / default HTTPS tarball  

## Publishing to destroythekraken.com

After `pack-release.sh`:

| File on site | Source |
|--------------|--------|
| `/hickmedia.sh` | `public/hickmedia.sh` or release root copy |
| `/hickmedia/latest.tar.gz` | `hickmedia-latest.tar.gz` from release |
| Optional `/hickmedia/SHA256SUMS` | for techs |

Set URL override if needed:

```bash
export HM_RELEASE_URL=https://www.destroythekraken.com/hickmedia/latest.tar.gz
```

(Keep `public/hickmedia.sh` `DEFAULT_RELEASE_URL` in sync when you change hosting paths.)

## Security notes (talk to customers honestly)

- `curl | sudo sh` trusts the **HTTPS site** and whoever can publish there.  
- Prefer HTTPS only; pin SHA256 with `HM_RELEASE_SHA256` when you want stricter checks.  
- USB installs avoid the network trust path for air‑gapped homes.  
- Never embed Bitwarden secrets in the tarball.

## Local test without website

```bash
bash installer/pack-release.sh --out /tmp/hm-rel
sudo sh /tmp/hm-rel/hickmedia.sh --local /tmp/hm-rel/payload --profile media-client --yes
```
