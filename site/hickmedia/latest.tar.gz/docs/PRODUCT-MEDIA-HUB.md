# Product: Sovereign Media Hub

**Internal codename:** HickMedia  
**Customer name:** Sovereign Media Hub (or “Valley Tech private media center”)  
**Purpose:** Easy on-prem media + entertainment desktop for homes and small sites that want **their own** library — not a rental stick.

## One-sentence pitch

> A private living-room media computer: watch your movies on **Jellyfin**, browse with **Firefox + Brave Search**, and optionally play retro games — all on hardware you own.

## OS (decide before install)

| Role | OS |
|------|-----|
| **Default customer** | Ubuntu Desktop **or** Kubuntu **26.04 LTS** |
| Pro audio interface (e.g. PreSonus) | Ubuntu Studio optional |
| Jellyfin-only mini PC | Ubuntu Server + Docker **or** Desktop `media-server` profile |

**Ubuntu Studio is overkill** for most customers (large audio toolchain). Keep Studio for audio specialists; product defaults target a normal desktop.

## Installer

```bash
sudo bash installer/install.sh --profile full-hub      # all-in-one
sudo bash installer/install.sh --profile media-server  # Jellyfin host
sudo bash installer/install.sh --profile media-client  # living room client
```

Details: [`installer/README.md`](../installer/README.md).

## Default entertainment desktop

- **Browser:** Firefox (system default)  
- **Search:** Brave Search (policy + homepage)  
- **Watch:** Jellyfin (Desktop app or local URL)  
- **Play:** RetroArch (optional) with couch hotkeys  
- **Appliance:** optional no-sleep + linger for always-on hubs  

## Jellyfin layout (server profile)

| Host path | Container |
|-----------|-----------|
| `/srv/mediahub/media/movies` | `/media/movies` |
| `/srv/mediahub/media/tv` | `/media/tv` |
| `/srv/mediahub/media/music` | `/media/music` |
| `/srv/mediahub/jellyfin/config` | `/config` |

Port: **8096** (override with `HM_JELLYFIN_PORT`).

## Family lab vs product

| | Family HickMedia | Customer install |
|--|------------------|------------------|
| Host | `hickmedia` / fam-rm | Their PC/mini-PC |
| Jellyfin | Often on um690 + NAS | On-box Docker (`media-server` / `full-hub`) |
| ROMs | Cached from NAS | Customer-provided, legal sources only |
| Scripts | Full lab tree | Installer + `/opt/mediahub` pointer |
| Secrets | Bitwarden | Customer passwords only |

## Cleanup policy (maintainers)

- **Product path:** `installer/`, `compose/jellyfin/` template, documented scripts under `scripts/` listed in `installer/PRODUCT-SCRIPTS.md`  
- **Family one-offs:** `scripts/legacy/` (MLP grabs, transfer status, old sudo-once variants)  
- **Never ship:** `compose/jellyfin-server/config|cache`, live DBs, logs, ROM dumps  

## Related VTS packaging

Offer as **Service 2 add-on**: “Private media center setup” after or with home network job.  
Do not lead cold calls with RetroArch complexity — lead with **own your movies on your network**.
