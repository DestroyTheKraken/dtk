# Pro audio (essential product path)

Movies, Music, and Gaming all share one **high-quality path**:

```
Apps (Jellyfin · Firefox · RetroArch · desktop)
        │
        ▼
PipeWire @ 48 kHz (locked)
        │
        ▼
USB audio interface  (PreSonus Studio 1810c reference; Focusrite/etc. OK)
        │
        ▼
External speakers / monitors / AVR
```

This is **not** optional. The installer always runs `hm_audio_pro_essential`.

## Profiles (latency vs stability)

| Command | Quantum | Use |
|---------|---------|-----|
| `ht-audio-profile.sh movies` | 1024 | Film/TV — stable |
| `ht-audio-profile.sh music` | 512 | Listening / light monitoring |
| `ht-audio-profile.sh gaming` | 2048 | RetroArch / GPU load — fewest xruns |
| `ht-audio-profile.sh hub` | 1024 | Default at login |

Desktop launchers: **Audio Movies / Music / Gaming**.

## Interface

- Autosuspend disabled (udev) for PreSonus / Focusrite / USB Audio class  
- WirePlumber prefers USB sinks over HDMI/onboard  
- PreSonus 1810c: multichannel capture → main outs (HW mix without Ardour 24/7)  
- Ardour: offline only, not autostart  

## Customer handoff

1. Plug interface USB → speakers on interface outs (not motherboard green jack).  
2. Login once → `ht-audio-route` service sets defaults.  
3. Check: `ht-audio-profile.sh status` or `health-check.sh`.  
